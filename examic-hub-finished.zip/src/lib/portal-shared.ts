/** Shared portal rules. No server imports — safe on the client. */

export const PLACEHOLDER_ACCOUNT = "0123456789";

export const ORDER_STATUSES = ["pending", "confirmed", "completed", "rejected"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

const MALPRACTICE =
  /\b(runz|expos?|leaked questions|exam leak|malpractice|question dump|live questions)\b|\b(sell|buy|purchase)\b.{0,48}\b(answers?|questions?)\b|\b(answers?|questions?)\b.{0,48}\b(before the exam|during the exam)\b/i;

export function isMalpracticeCopy(text: string): boolean {
  return MALPRACTICE.test(text);
}

export function naira(amount: number): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function whatsappHref(raw: string): string {
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("0")) digits = `234${digits.slice(1)}`;
  else if (digits.length === 10) digits = `234${digits}`;
  return `https://wa.me/${digits}`;
}

export function assertImageData(value: unknown, label: string): string {
  if (typeof value !== "string" || !value.startsWith("data:image/")) {
    throw new Error(`${label} must be a photo`);
  }
  const comma = value.indexOf(",");
  const meta = comma === -1 ? "" : value.slice(0, comma);
  if (!/^data:image\/(jpeg|png|webp);base64$/i.test(meta)) {
    throw new Error(`${label} must be a JPG, PNG, or WebP`);
  }
  if (value.length > 500_000) throw new Error(`${label} is too large. Try a smaller photo.`);
  return value;
}

export function assertWhatsapp(value: unknown): string {
  if (typeof value !== "string") throw new Error("Enter a WhatsApp number");
  const trimmed = value.trim();
  const digits = trimmed.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) {
    throw new Error("Enter a valid WhatsApp number");
  }
  return trimmed;
}
