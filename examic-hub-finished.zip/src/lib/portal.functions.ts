import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { ORDER_STATUSES, type OrderStatus } from "@/lib/portal-shared";

/** Bootstraps the office account before anyone is signed in. No personal data. */
export const ensurePortal = createServerFn({ method: "GET" }).handler(async () => {
  const { ensureSeed } = await import("./seed.server");
  await ensureSeed();
  return { ok: true as const };
});

export const whoAmI = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { loadWho } = await import("./portal.server");
    return loadWho(context.userId);
  });

export const getPortalHome = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { loadPortal } = await import("./portal.server");
    return loadPortal(context.userId);
  });

export const updateProfile = createServerFn({ method: "POST" })
  .validator((input: { fullName: string; avatar: string | null; whatsapp: string | null }) => {
    if (!input || typeof input.fullName !== "string") throw new Error("Enter your full name");
    return {
      fullName: input.fullName,
      avatar: typeof input.avatar === "string" ? input.avatar : null,
      whatsapp: typeof input.whatsapp === "string" ? input.whatsapp : null,
    };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { saveProfile } = await import("./portal.server");
    return saveProfile(context.userId, data);
  });

export const requestService = createServerFn({ method: "POST" })
  .validator(
    (input: { serviceId: number; whatsapp: string; receipt: string; note: string }) => {
      if (!input || typeof input.receipt !== "string" || typeof input.whatsapp !== "string") {
        throw new Error("Add your receipt and WhatsApp number");
      }
      return {
        serviceId: Number(input.serviceId),
        whatsapp: input.whatsapp,
        receipt: input.receipt,
        note: typeof input.note === "string" ? input.note : "",
      };
    },
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { createOrder } = await import("./portal.server");
    return createOrder(context.userId, data);
  });

export const getAdminHome = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { loadAdmin } = await import("./portal.server");
    return loadAdmin(context.userId);
  });

export const upsertService = createServerFn({ method: "POST" })
  .validator(
    (input: {
      id: number | null;
      title: string;
      description: string;
      priceNaira: number;
      category: string;
      active: boolean;
    }) => input,
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { saveService } = await import("./portal.server");
    return saveService(context.userId, data);
  });

export const deleteService = createServerFn({ method: "POST" })
  .validator((id: number) => {
    const n = Number(id);
    if (!Number.isInteger(n)) throw new Error("Unknown service");
    return n;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { removeService } = await import("./portal.server");
    return removeService(context.userId, data);
  });

export const updatePayment = createServerFn({ method: "POST" })
  .validator(
    (input: { bankName: string; accountName: string; accountNumber: string; note: string }) =>
      input,
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { savePayment } = await import("./portal.server");
    return savePayment(context.userId, data);
  });

export const updateOrder = createServerFn({ method: "POST" })
  .validator((input: { id: number; status: string; adminNote: string }) => {
    if (!(ORDER_STATUSES as readonly string[]).includes(input.status)) {
      throw new Error("Unknown status");
    }
    return {
      id: Number(input.id),
      status: input.status as OrderStatus,
      adminNote: input.adminNote ?? "",
    };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { setOrderStatus } = await import("./portal.server");
    return setOrderStatus(context.userId, data);
  });

export const fetchReceipt = createServerFn({ method: "POST" })
  .validator((id: number) => {
    const n = Number(id);
    if (!Number.isInteger(n)) throw new Error("Unknown request");
    return n;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { readReceipt } = await import("./portal.server");
    return readReceipt(context.userId, data);
  });
