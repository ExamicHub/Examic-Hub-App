import { authClient } from "@/lib/auth/client";

const BEARER_KEY = "grok-auth.bearer-token";

function rememberToken(token: string | null) {
  if (typeof window === "undefined" || !token) return;
  try {
    window.sessionStorage.setItem(BEARER_KEY, token);
  } catch {
    /* storage unavailable */
  }
}

type AuthPayload = {
  message?: string;
  token?: string | null;
};

/**
 * Email sign-in / sign-up against this app's Better Auth.
 * Stores the session bearer so the live preview (partitioned cookies) stays signed in.
 */
export async function emailAuth(
  kind: "sign-in" | "sign-up",
  body: { email: string; password: string; name?: string },
): Promise<void> {
  const res = await fetch(`/api/auth/${kind}/email`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  const payload = (await res.json().catch(() => null)) as AuthPayload | null;
  if (!res.ok) {
    throw new Error(payload?.message || "That didn't work. Check the details and try again.");
  }
  rememberToken(res.headers.get("set-auth-token") || payload?.token || null);
  await authClient.getSession();
}
