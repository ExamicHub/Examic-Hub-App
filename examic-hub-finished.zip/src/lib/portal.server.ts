import { getSql, type Sql } from "@/lib/db";
import { ensureSeed } from "@/lib/seed.server";
import {
  ORDER_STATUSES,
  assertImageData,
  assertWhatsapp,
  isMalpracticeCopy,
  type OrderStatus,
} from "@/lib/portal-shared";

const ADMIN_EMAIL = "examichubeduconsult@gmail.com";

export type Actor = {
  userId: string;
  email: string;
  name: string;
  avatar: string | null;
  whatsapp: string | null;
  role: "student" | "admin";
  hasProfile: boolean;
};

export type ServiceRow = {
  id: number;
  title: string;
  description: string;
  priceNaira: number;
  category: string;
  active: boolean;
};

export type PaymentRow = {
  bankName: string;
  accountName: string;
  accountNumber: string;
  note: string;
};

export type OrderRow = {
  id: number;
  serviceTitle: string;
  priceNaira: number;
  whatsapp: string;
  note: string;
  status: OrderStatus;
  adminNote: string;
  createdAt: string;
  studentName?: string;
  studentEmail?: string;
};

type ProfileDb = {
  user_id: string;
  email: string;
  full_name: string;
  avatar: string | null;
  whatsapp: string | null;
  role: string;
};

function stamp(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  return typeof value === "string" ? value : "";
}

function asStatus(value: string): OrderStatus {
  return (ORDER_STATUSES as readonly string[]).includes(value) ? (value as OrderStatus) : "pending";
}

async function sqlReady(): Promise<Sql> {
  await ensureSeed();
  return getSql();
}

export async function requireActor(userId: string): Promise<Actor> {
  const sql = await sqlReady();
  const users = await sql<{ id: string; email: string; name: string }>`
    select id, email, name from "user" where id = ${userId} limit 1
  `;
  const user = users[0];
  if (!user) throw new Error("Account not found");
  const email = user.email.toLowerCase();

  if (email === ADMIN_EMAIL) {
    await sql`
      insert into profiles (user_id, email, full_name, role)
      values (${userId}, ${email}, ${user.name}, 'admin')
      on conflict (user_id) do update set role = 'admin', email = ${email}
    `;
  }

  const profiles = await sql<ProfileDb>`
    select user_id, email, full_name, avatar, whatsapp, role
    from profiles where user_id = ${userId} limit 1
  `;
  const profile = profiles[0];
  const role: Actor["role"] =
    email === ADMIN_EMAIL || profile?.role === "admin" ? "admin" : "student";

  return {
    userId,
    email,
    name: profile?.full_name || user.name,
    avatar: profile?.avatar ?? null,
    whatsapp: profile?.whatsapp ?? null,
    role,
    hasProfile: Boolean(profile),
  };
}

function mapService(row: {
  id: number;
  title: string;
  description: string;
  price_naira: number;
  category: string;
  active: boolean;
}): ServiceRow {
  return {
    id: Number(row.id),
    title: row.title,
    description: row.description,
    priceNaira: Number(row.price_naira),
    category: row.category,
    active: Boolean(row.active),
  };
}

async function readPayment(sql: Sql): Promise<PaymentRow> {
  const rows = await sql<{
    bank_name: string;
    account_name: string;
    account_number: string;
    note: string;
  }>`
    select bank_name, account_name, account_number, note
    from payment_settings where id = 1
  `;
  const row = rows[0];
  return {
    bankName: row?.bank_name ?? "",
    accountName: row?.account_name ?? "",
    accountNumber: row?.account_number ?? "",
    note: row?.note ?? "",
  };
}

export async function loadWho(userId: string) {
  const actor = await requireActor(userId);
  return {
    role: actor.role,
    name: actor.name,
    email: actor.email,
    avatar: actor.avatar,
    hasProfile: actor.hasProfile,
  };
}

export async function loadPortal(userId: string) {
  const actor = await requireActor(userId);
  const sql = await getSql();
  const services = await sql<{
    id: number;
    title: string;
    description: string;
    price_naira: number;
    category: string;
    active: boolean;
  }>`
    select id, title, description, price_naira, category, active
    from services
    where active = true
    order by sort_order, id
  `;
  const orders = await sql<{
    id: number;
    service_title: string;
    price_naira: number;
    whatsapp: string;
    note: string;
    status: string;
    admin_note: string;
    created_at: unknown;
  }>`
    select id, service_title, price_naira, whatsapp, note, status, admin_note, created_at
    from orders
    where user_id = ${userId}
    order by created_at desc
  `;
  return {
    actor: {
      name: actor.name,
      email: actor.email,
      avatar: actor.avatar,
      whatsapp: actor.whatsapp,
      role: actor.role,
      hasProfile: actor.hasProfile,
    },
    services: services.map(mapService),
    payment: await readPayment(sql),
    orders: orders.map((row) => ({
      id: Number(row.id),
      serviceTitle: row.service_title,
      priceNaira: Number(row.price_naira),
      whatsapp: row.whatsapp,
      note: row.note,
      status: asStatus(row.status),
      adminNote: row.admin_note,
      createdAt: stamp(row.created_at),
    })),
  };
}

export async function saveProfile(
  userId: string,
  input: { fullName: string; avatar: string | null; whatsapp: string | null },
) {
  const actor = await requireActor(userId);
  const fullName = input.fullName.trim();
  if (fullName.length < 2 || fullName.length > 80) {
    throw new Error("Enter your full name");
  }
  let avatar = actor.avatar;
  if (input.avatar) avatar = assertImageData(input.avatar, "Profile photo");
  if (actor.role !== "admin" && !avatar) throw new Error("Add a profile photo");

  let whatsapp = actor.whatsapp;
  if (input.whatsapp && input.whatsapp.trim()) whatsapp = assertWhatsapp(input.whatsapp);

  const sql = await getSql();
  await sql`
    insert into profiles (user_id, email, full_name, avatar, whatsapp, role)
    values (${userId}, ${actor.email}, ${fullName}, ${avatar}, ${whatsapp}, ${actor.role})
    on conflict (user_id) do update set
      full_name = ${fullName},
      avatar = ${avatar},
      whatsapp = ${whatsapp},
      email = ${actor.email},
      updated_at = now()
  `;
  await sql`
    update "user" set name = ${fullName}, "updatedAt" = now() where id = ${userId}
  `;
  return { ok: true as const };
}

export async function createOrder(
  userId: string,
  input: { serviceId: number; whatsapp: string; receipt: string; note: string },
) {
  const actor = await requireActor(userId);
  if (!actor.hasProfile || actor.name.trim().length < 2) {
    throw new Error("Add your full name before requesting a service");
  }
  if (actor.role !== "admin" && !actor.avatar) {
    throw new Error("Add a profile photo before requesting a service");
  }
  const whatsapp = assertWhatsapp(input.whatsapp);
  const receipt = assertImageData(input.receipt, "Payment receipt");
  const note = input.note.trim().slice(0, 500);
  const serviceId = Number(input.serviceId);
  if (!Number.isInteger(serviceId)) throw new Error("Choose a service");

  const sql = await getSql();
  const services = await sql<{
    id: number;
    title: string;
    price_naira: number;
    active: boolean;
  }>`
    select id, title, price_naira, active from services where id = ${serviceId} limit 1
  `;
  const service = services[0];
  if (!service || !service.active) throw new Error("That service is not available");

  const inserted = await sql<{ id: number }>`
    insert into orders (
      user_id, service_id, service_title, price_naira, whatsapp, receipt, note
    )
    values (
      ${userId},
      ${service.id},
      ${service.title},
      ${service.price_naira},
      ${whatsapp},
      ${receipt},
      ${note}
    )
    returning id
  `;
  return { id: Number(inserted[0]?.id ?? 0) };
}

async function requireAdmin(userId: string): Promise<Actor> {
  const actor = await requireActor(userId);
  if (actor.role !== "admin") throw new Error("Forbidden");
  return actor;
}

export async function loadAdmin(userId: string) {
  await requireAdmin(userId);
  const sql = await getSql();
  const services = await sql<{
    id: number;
    title: string;
    description: string;
    price_naira: number;
    category: string;
    active: boolean;
  }>`
    select id, title, description, price_naira, category, active
    from services
    order by sort_order, id
  `;
  const orders = await sql<{
    id: number;
    service_title: string;
    price_naira: number;
    whatsapp: string;
    note: string;
    status: string;
    admin_note: string;
    created_at: unknown;
    student_name: string;
    student_email: string;
  }>`
    select
      o.id,
      o.service_title,
      o.price_naira,
      o.whatsapp,
      o.note,
      o.status,
      o.admin_note,
      o.created_at,
      coalesce(p.full_name, u.name) as student_name,
      u.email as student_email
    from orders o
    join "user" u on u.id = o.user_id
    left join profiles p on p.user_id = o.user_id
    order by o.created_at desc
    limit 100
  `;
  return {
    services: services.map(mapService),
    payment: await readPayment(sql),
    orders: orders.map((row) => ({
      id: Number(row.id),
      serviceTitle: row.service_title,
      priceNaira: Number(row.price_naira),
      whatsapp: row.whatsapp,
      note: row.note,
      status: asStatus(row.status),
      adminNote: row.admin_note,
      createdAt: stamp(row.created_at),
      studentName: row.student_name,
      studentEmail: row.student_email,
    })),
  };
}

function cleanServiceCopy(title: string, description: string, category: string) {
  const blob = `${title}\n${description}\n${category}`;
  if (isMalpracticeCopy(blob)) {
    throw new Error(
      "Exam malpractice services — including runz, expo, or leaked questions — cannot be listed.",
    );
  }
}

export async function saveService(
  userId: string,
  input: {
    id: number | null;
    title: string;
    description: string;
    priceNaira: number;
    category: string;
    active: boolean;
  },
) {
  await requireAdmin(userId);
  const title = input.title.trim();
  const description = input.description.trim();
  const category = input.category.trim();
  if (title.length < 3 || title.length > 80) throw new Error("Give the service a clear name");
  if (description.length < 8 || description.length > 400) {
    throw new Error("Add a short description");
  }
  if (category.length < 2 || category.length > 40) throw new Error("Add a category");
  const price = Number(input.priceNaira);
  if (!Number.isInteger(price) || price < 0 || price > 5_000_000) {
    throw new Error("Enter a price in naira");
  }
  cleanServiceCopy(title, description, category);

  const sql = await getSql();
  if (input.id) {
    const updated = await sql<{ id: number }>`
      update services set
        title = ${title},
        description = ${description},
        price_naira = ${price},
        category = ${category},
        active = ${input.active}
      where id = ${input.id}
      returning id
    `;
    if (!updated[0]) throw new Error("Service not found");
    return { id: Number(updated[0].id) };
  }
  const next = await sql<{ n: number }>`select coalesce(max(sort_order), 0)::int as n from services`;
  const inserted = await sql<{ id: number }>`
    insert into services (title, description, price_naira, category, active, sort_order)
    values (${title}, ${description}, ${price}, ${category}, ${input.active}, ${(next[0]?.n ?? 0) + 1})
    returning id
  `;
  return { id: Number(inserted[0]?.id ?? 0) };
}

export async function removeService(userId: string, id: number) {
  await requireAdmin(userId);
  const sql = await getSql();
  const used = await sql<{ n: number }>`
    select count(*)::int as n from orders where service_id = ${id}
  `;
  if ((used[0]?.n ?? 0) > 0) {
    await sql`update services set active = false where id = ${id}`;
    return { archived: true as const };
  }
  await sql`delete from services where id = ${id}`;
  return { archived: false as const };
}

export async function savePayment(
  userId: string,
  input: { bankName: string; accountName: string; accountNumber: string; note: string },
) {
  await requireAdmin(userId);
  const bankName = input.bankName.trim();
  const accountName = input.accountName.trim();
  const accountNumber = input.accountNumber.replace(/\s/g, "");
  const note = input.note.trim().slice(0, 280);
  if (bankName.length < 2 || bankName.length > 60) throw new Error("Enter the bank name");
  if (accountName.length < 2 || accountName.length > 80) throw new Error("Enter the account name");
  if (!/^\d{10}$/.test(accountNumber)) throw new Error("Nigerian account numbers are 10 digits");
  const sql = await getSql();
  await sql`
    insert into payment_settings (id, bank_name, account_name, account_number, note)
    values (1, ${bankName}, ${accountName}, ${accountNumber}, ${note})
    on conflict (id) do update set
      bank_name = ${bankName},
      account_name = ${accountName},
      account_number = ${accountNumber},
      note = ${note}
  `;
  return { ok: true as const };
}

export async function setOrderStatus(
  userId: string,
  input: { id: number; status: OrderStatus; adminNote: string },
) {
  await requireAdmin(userId);
  if (!(ORDER_STATUSES as readonly string[]).includes(input.status)) {
    throw new Error("Unknown status");
  }
  const note = input.adminNote.trim().slice(0, 400);
  const sql = await getSql();
  const updated = await sql<{ id: number }>`
    update orders
    set status = ${input.status}, admin_note = ${note}, updated_at = now()
    where id = ${input.id}
    returning id
  `;
  if (!updated[0]) throw new Error("Request not found");
  return { ok: true as const };
}

export async function readReceipt(userId: string, orderId: number) {
  const actor = await requireActor(userId);
  const sql = await getSql();
  const rows = await sql<{ user_id: string; receipt: string }>`
    select user_id, receipt from orders where id = ${orderId} limit 1
  `;
  const row = rows[0];
  if (!row) throw new Error("Receipt not found");
  if (actor.role !== "admin" && row.user_id !== userId) throw new Error("Receipt not found");
  return { receipt: row.receipt };
}
