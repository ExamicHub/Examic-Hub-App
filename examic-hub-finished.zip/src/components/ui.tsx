import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "gold" | "line" | "ghost" | "danger";
}) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-50",
        tap,
        variant === "primary" && "bg-forest text-paper hover:bg-forest/90",
        variant === "gold" && "bg-gold text-ink hover:bg-gold/90",
        variant === "line" && "border border-ink/15 bg-sheet text-ink hover:bg-paper",
        variant === "ghost" && "text-ink hover:bg-ink/5",
        variant === "danger" && "border border-ink/15 bg-sheet text-ink hover:bg-ink/5",
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
      {hint ? <span className="block text-ink/60">{hint}</span> : null}
    </label>
  );
}

export const inputClass =
  "min-h-11 w-full rounded-md border border-ink/15 bg-sheet px-3 text-base text-ink outline-none placeholder:text-ink/40";

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(inputClass, props.className)} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(inputClass, "min-h-24 py-2", props.className)}
    />
  );
}

export function PageSkeleton() {
  return (
    <div className="mx-auto max-w-5xl space-y-4 px-4 py-8">
      <div className="h-8 w-40 animate-pulse rounded-md bg-ink/10" />
      <div className="h-28 animate-pulse rounded-lg bg-ink/10" />
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="h-36 animate-pulse rounded-lg bg-ink/10" />
        <div className="h-36 animate-pulse rounded-lg bg-ink/10" />
      </div>
    </div>
  );
}

const STATUS_LABEL: Record<string, string> = {
  pending: "Awaiting check",
  confirmed: "Payment seen",
  completed: "Done",
  rejected: "Not accepted",
};

export function StatusPill({ status }: { status: string }) {
  const tone =
    status === "completed"
      ? "bg-forest text-paper"
      : status === "confirmed"
        ? "bg-forest/10 text-forest"
        : status === "rejected"
          ? "bg-ink/10 text-ink/70"
          : "bg-gold/20 text-ink";
  return (
    <span className={cn("inline-flex rounded-full px-2.5 py-1 text-xs font-medium", tone)}>
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function messageOf(err: unknown): string {
  if (err instanceof Error && err.message) return err.message;
  if (typeof err === "object" && err && "message" in err) {
    const message = (err as { message?: unknown }).message;
    if (typeof message === "string" && message) return message;
  }
  return "Something went wrong. Try again.";
}
