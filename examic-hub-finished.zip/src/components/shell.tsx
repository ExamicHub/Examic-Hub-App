import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { whoAmI } from "@/lib/portal.functions";
import { cn } from "@/lib/utils";

function Wordmark() {
  return (
    <Link to="/" className="flex items-center gap-3">
      <span className="grid h-11 w-11 place-items-center rounded-md bg-forest font-display text-lg text-paper">
        Eh
      </span>
      <span>
        <span className="block font-display text-lg leading-none">Examic Hub</span>
        <span className="mt-1 block h-0.5 w-8 bg-gold" />
        <span className="mt-1 block text-xs uppercase tracking-widest text-ink/55">Edu Consult</span>
      </span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  const [role, setRole] = useState<string | null>(null);
  const [avatar, setAvatar] = useState<string | null>(null);
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!mounted || !user) {
      setRole(null);
      setAvatar(null);
      return;
    }
    let cancelled = false;
    whoAmI()
      .then((me) => {
        if (cancelled) return;
        setRole(me.role);
        setAvatar(me.avatar);
      })
      .catch(() => {
        if (!cancelled) setRole(null);
      });
    return () => {
      cancelled = true;
    };
  }, [mounted, user?.id]);

  const showSession = mounted && !isPending;
  const gateLocked =
    showSession &&
    authEnabled &&
    hasGateSessionMarker() &&
    !window.sessionStorage.getItem("grok-auth.bearer-token");

  const linkClass = (path: string) =>
    cn(
      "inline-flex min-h-11 items-center rounded-md px-3 text-sm font-medium",
      pathname === path ? "bg-forest text-paper" : "text-ink hover:bg-ink/5",
    );

  return (
    <div className="min-h-screen">
      <header className="border-b border-ink/10 bg-sheet">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
          <Wordmark />
          <nav className="ml-auto flex flex-wrap items-center gap-1">
            {showSession && user ? (
              <>
                <Link to="/portal" className={linkClass("/portal")}>
                  Portal
                </Link>
                {role === "admin" ? (
                  <Link to="/admin" className={linkClass("/admin")}>
                    Office
                  </Link>
                ) : (
                  <Link to="/login" className={linkClass("/login")}>
                    Staff
                  </Link>
                )}
                <span className="mx-1 hidden h-6 w-px bg-ink/10 sm:block" />
                <span className="inline-flex min-h-11 items-center gap-2 px-1 text-sm">
                  {avatar ? (
                    <img src={avatar} alt="" className="h-8 w-8 rounded-full object-cover" />
                  ) : (
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-forest/10 text-xs font-medium text-forest">
                      {(user.displayName ?? user.primaryEmail ?? "S").charAt(0).toUpperCase()}
                    </span>
                  )}
                  <span className="max-w-32 truncate">{user.displayName ?? "Student"}</span>
                </span>
                {authEnabled && !gateLocked ? (
                  <button
                    type="button"
                    disabled={signingOut}
                    onClick={() => {
                      setSigningOut(true);
                      void signOut("/").catch(() => setSigningOut(false));
                    }}
                    className="inline-flex min-h-11 items-center px-2 text-sm text-ink/70 underline-offset-4 hover:underline disabled:opacity-60"
                  >
                    {signingOut ? "Signing out…" : "Sign out"}
                  </button>
                ) : null}
              </>
            ) : showSession ? (
              <>
                <Link to="/login" className={linkClass("/login")}>
                  Sign in
                </Link>
                <Link
                  to="/signup"
                  className="inline-flex min-h-11 items-center rounded-md bg-forest px-3 text-sm font-medium text-paper"
                >
                  Create account
                </Link>
              </>
            ) : (
              <span className="h-11 w-28 animate-pulse rounded-md bg-ink/10" />
            )}
          </nav>
        </div>
      </header>
      {children}
    </div>
  );
}
