import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Shell } from "@/components/shell";
import {
  Button,
  Field,
  PageSkeleton,
  StatusPill,
  TextArea,
  TextInput,
  messageOf,
} from "@/components/ui";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { compressImage } from "@/lib/images";
import { naira, PLACEHOLDER_ACCOUNT, whatsappHref } from "@/lib/portal-shared";
import {
  fetchReceipt,
  getPortalHome,
  requestService,
  updateProfile,
} from "@/lib/portal.functions";

export const Route = createFileRoute("/portal")({
  component: PortalPage,
  head: () => ({ meta: [{ title: "My portal · Examic Hub" }] }),
});

type Home = Awaited<ReturnType<typeof getPortalHome>>;
type Service = Home["services"][number];

function PortalPage() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  const [home, setHome] = useState<Home | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState<Service | null>(null);

  useEffect(() => setMounted(true), []);

  async function reload() {
    const next = await getPortalHome();
    setHome(next);
  }

  useEffect(() => {
    if (!mounted || !user) return;
    let cancelled = false;
    getPortalHome()
      .then((next) => {
        if (!cancelled) setHome(next);
      })
      .catch((err) => {
        if (!cancelled) setError(messageOf(err));
      });
    return () => {
      cancelled = true;
    };
  }, [mounted, user?.id]);

  if (!mounted || isPending || (user && !home && !error)) {
    return (
      <Shell>
        <PageSkeleton />
      </Shell>
    );
  }
  if (!user) return <RedirectToSignIn />;
  if (error || !home) {
    return (
      <Shell>
        <main className="mx-auto max-w-5xl px-4 py-10">
          <p>{error ?? "Could not open your portal."}</p>
        </main>
      </Shell>
    );
  }

  const needsPhoto = home.actor.role !== "admin" && !home.actor.avatar;

  return (
    <Shell>
      <main className="mx-auto max-w-5xl space-y-10 px-4 py-8">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-forest">Student portal</p>
            <h1 className="mt-2 font-display text-4xl">Hello, {home.actor.name.split(" ")[0]}.</h1>
            <p className="mt-2 text-sm text-ink/65">{home.actor.email}</p>
          </div>
          {home.actor.avatar ? (
            <img
              src={home.actor.avatar}
              alt=""
              className="h-16 w-16 rounded-full object-cover"
            />
          ) : null}
        </header>

        <ProfileCard
          name={home.actor.name}
          avatar={home.actor.avatar}
          whatsapp={home.actor.whatsapp}
          needsPhoto={needsPhoto}
          onSaved={() => {
            toast.success("Profile saved");
            return reload();
          }}
        />

        <section>
          <h2 className="font-display text-3xl">Services</h2>
          <p className="mt-2 max-w-xl text-sm text-ink/70">
            Prices are set by the office. Pay the account shown, then send the receipt and the
            WhatsApp number we should use.
          </p>
          {home.services.length === 0 ? (
            <p className="mt-4 rounded-lg border border-dashed border-ink/20 bg-sheet p-6 text-sm">
              No services are listed right now. Check back soon.
            </p>
          ) : (
            <ul className="mt-5 grid gap-4 sm:grid-cols-2">
              {home.services.map((service) => (
                <li key={service.id} className="flex flex-col rounded-lg border border-ink/10 bg-sheet p-5">
                  <p className="text-xs uppercase tracking-widest text-ink/50">{service.category}</p>
                  <h3 className="mt-2 text-2xl">{service.title}</h3>
                  <p className="mt-2 flex-1 text-sm leading-relaxed text-ink/70">{service.description}</p>
                  <p className="mt-4 font-display text-3xl tabular-nums text-gold">
                    {naira(service.priceNaira)}
                  </p>
                  <Button className="mt-4" onClick={() => setPicked(service)} disabled={needsPhoto || !home.actor.hasProfile}>
                    Request this
                  </Button>
                </li>
              ))}
            </ul>
          )}
          {needsPhoto ? (
            <p className="mt-3 text-sm text-ink/70">Add a profile photo above before you request a service.</p>
          ) : null}
        </section>

        <section>
          <h2 className="font-display text-3xl">My requests</h2>
          {home.orders.length === 0 ? (
            <p className="mt-4 text-sm text-ink/70">You have not requested anything yet.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {home.orders.map((order) => (
                <li key={order.id} className="rounded-lg border border-ink/10 bg-sheet p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-lg">{order.serviceTitle}</h3>
                      <p className="mt-1 text-sm tabular-nums text-ink/70">
                        {naira(order.priceNaira)} · {formatWhen(order.createdAt)}
                      </p>
                      <p className="mt-1 text-sm">
                        WhatsApp:{" "}
                        <a
                          className="text-forest underline-offset-4 hover:underline"
                          href={whatsappHref(order.whatsapp)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          {order.whatsapp}
                        </a>
                      </p>
                      {order.note ? <p className="mt-2 text-sm text-ink/70">{order.note}</p> : null}
                      {order.adminNote ? (
                        <p className="mt-2 text-sm">Office note: {order.adminNote}</p>
                      ) : null}
                    </div>
                    <StatusPill status={order.status} />
                  </div>
                  <ReceiptButton id={order.id} />
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
      {picked ? (
        <RequestSheet
          service={picked}
          payment={home.payment}
          defaultWhatsapp={home.actor.whatsapp ?? ""}
          onClose={() => setPicked(null)}
          onDone={async () => {
            setPicked(null);
            toast.success("Request sent. We'll confirm the receipt and reach you on WhatsApp.");
            await reload();
          }}
        />
      ) : null}
    </Shell>
  );
}

function formatWhen(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-NG", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function ProfileCard({
  name,
  avatar,
  whatsapp,
  needsPhoto,
  onSaved,
}: {
  name: string;
  avatar: string | null;
  whatsapp: string | null;
  needsPhoto: boolean;
  onSaved: () => Promise<void>;
}) {
  const [fullName, setFullName] = useState(name);
  const [photo, setPhoto] = useState<string | null>(null);
  const [line, setLine] = useState(whatsapp ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await updateProfile({
        data: { fullName, avatar: photo, whatsapp: line.trim() ? line : null },
      });
      setPhoto(null);
      await onSaved();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4 rounded-lg border border-ink/10 bg-sheet p-5 sm:grid-cols-[auto_1fr]">
      <div>
        {photo || avatar ? (
          <img src={photo || avatar || ""} alt="" className="h-20 w-20 rounded-full object-cover" />
        ) : (
          <span className="grid h-20 w-20 place-items-center rounded-full bg-forest/10 font-display text-2xl text-forest">
            {name.charAt(0).toUpperCase()}
          </span>
        )}
      </div>
      <div className="space-y-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="font-display text-2xl">Your profile</h2>
          {needsPhoto ? <span className="text-sm text-gold">Photo still needed</span> : null}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Full name">
            <TextInput value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </Field>
          <Field label="WhatsApp" hint="Optional here. Each request still asks for one.">
            <TextInput
              inputMode="tel"
              placeholder="0803 000 0000"
              value={line}
              onChange={(e) => setLine(e.target.value)}
            />
          </Field>
        </div>
        <Field label="Profile photo">
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-ink/5 file:px-3 file:text-sm"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              void compressImage(file, 720)
                .then(setPhoto)
                .catch((err) => setError(messageOf(err)));
            }}
          />
        </Field>
        {error ? <p className="text-sm">{error}</p> : null}
        <Button type="submit" variant="line" disabled={busy}>
          {busy ? "Saving…" : "Save profile"}
        </Button>
      </div>
    </form>
  );
}

function RequestSheet({
  service,
  payment,
  defaultWhatsapp,
  onClose,
  onDone,
}: {
  service: Service;
  payment: Home["payment"];
  defaultWhatsapp: string;
  onClose: () => void;
  onDone: () => Promise<void>;
}) {
  const [whatsapp, setWhatsapp] = useState(defaultWhatsapp);
  const [note, setNote] = useState("");
  const [receipt, setReceipt] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const unpublished = payment.accountNumber === PLACEHOLDER_ACCOUNT || !payment.accountNumber;

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!receipt) {
      setError("Upload a photo of your payment receipt");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await requestService({
        data: { serviceId: service.id, whatsapp, receipt, note },
      });
      await onDone();
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-ink/40 sm:items-center sm:p-6">
      <form
        onSubmit={onSubmit}
        className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-lg bg-sheet p-5 shadow-lg sm:rounded-lg"
        role="dialog"
        aria-labelledby="request-title"
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-widest text-ink/50">{service.category}</p>
            <h2 id="request-title" className="mt-1 font-display text-3xl">
              {service.title}
            </h2>
            <p className="mt-1 font-display text-3xl tabular-nums text-gold">{naira(service.priceNaira)}</p>
          </div>
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>

        <div className="mt-4 rounded-md border border-ink/10 bg-paper p-4">
          <p className="text-xs uppercase tracking-widest text-ink/50">Pay into</p>
          {unpublished ? (
            <p className="mt-2 text-sm">
              The office has not published a real account yet. You can browse services, but payment
              is paused until they update the bank details.
            </p>
          ) : (
            <dl className="mt-2 space-y-1 text-sm">
              <div className="flex justify-between gap-3">
                <dt className="text-ink/60">Bank</dt>
                <dd className="font-medium">{payment.bankName}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-ink/60">Account name</dt>
                <dd className="text-right font-medium">{payment.accountName}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-ink/60">Account number</dt>
                <dd className="font-display text-xl tabular-nums">{payment.accountNumber}</dd>
              </div>
            </dl>
          )}
          {payment.note ? <p className="mt-3 text-sm text-ink/70">{payment.note}</p> : null}
        </div>

        <div className="mt-4 space-y-3">
          <Field label="Your WhatsApp number" hint="This is where the service will be delivered.">
            <TextInput
              required
              inputMode="tel"
              placeholder="0803 000 0000"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
            />
          </Field>
          <Field label="Payment receipt" hint="A photo of the transfer alert or teller.">
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-forest file:px-3 file:text-sm file:text-paper"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                void compressImage(file, 1280)
                  .then(setReceipt)
                  .catch((err) => setError(messageOf(err)));
              }}
            />
          </Field>
          {receipt ? (
            <img src={receipt} alt="Receipt preview" className="max-h-48 w-full rounded-md object-contain bg-paper" />
          ) : null}
          <Field label="Note for the office" hint="Optional. Subjects, exam year, or registration details.">
            <TextArea value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} />
          </Field>
          {error ? <p className="text-sm">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={busy || unpublished}>
            {busy ? "Sending…" : "Send receipt"}
          </Button>
        </div>
      </form>
    </div>
  );
}

function ReceiptButton({ id }: { id: number }) {
  const [src, setSrc] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (src) {
    return (
      <img src={src} alt="Your payment receipt" className="mt-3 max-h-64 w-full rounded-md object-contain bg-paper" />
    );
  }
  return (
    <Button
      variant="ghost"
      className="mt-2 px-0"
      disabled={busy}
      onClick={() => {
        setBusy(true);
        fetchReceipt({ data: id })
          .then((row) => setSrc(row.receipt))
          .catch((err) => toast.error(messageOf(err)))
          .finally(() => setBusy(false));
      }}
    >
      {busy ? "Loading receipt…" : "View receipt"}
    </Button>
  );
}
