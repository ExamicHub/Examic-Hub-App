import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, GraduationCap, Landmark, MessageCircle } from "lucide-react";
import { Shell } from "@/components/shell";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

const STEPS = [
  {
    n: "01",
    title: "Open an account",
    body: "Add your full name, email, and a profile photo so the office knows who is asking.",
  },
  {
    n: "02",
    title: "Pay the published account",
    body: "Each service shows the current price and the bank details the office is using.",
  },
  {
    n: "03",
    title: "Send receipt and WhatsApp",
    body: "Upload a photo of the transfer alert and the number we should reach you on.",
  },
];

const LANES = [
  {
    icon: FileText,
    title: "Document printing",
    body: "JAMB result slips, admission letters, and WAEC or NECO result reprints.",
  },
  {
    icon: GraduationCap,
    title: "Tutorial classes",
    body: "Pay for lesson support and tell us the subjects in your request note.",
  },
  {
    icon: Landmark,
    title: "Registration help",
    body: "JAMB registration, O'Level upload, and change of institution or course.",
  },
];

function Home() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const ready = mounted && !isPending;

  return (
    <Shell>
      <main>
        <section className="mx-auto grid max-w-5xl gap-8 px-4 py-10 sm:py-16 lg:grid-cols-[1.2fr_0.8fr] lg:items-end">
          <div className="rise">
            <p className="text-xs font-medium uppercase tracking-widest text-forest">Student portal</p>
            <h1 className="mt-3 max-w-xl font-display text-4xl leading-tight text-ink sm:text-5xl">
              Your exam paperwork, without the queue.
            </h1>
            <p className="mt-4 max-w-lg text-lg leading-relaxed text-ink/75">
              Examic Hub Edu Consult takes JAMB prints, tutorial payments, and registration support
              off the corridor. You request it here. We confirm the receipt and reply on WhatsApp.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              {ready ? (
                user ? (
                  <Link
                    to="/portal"
                    className="inline-flex min-h-11 items-center rounded-md bg-forest px-5 text-sm font-medium text-paper"
                  >
                    Open my portal
                  </Link>
                ) : (
                  <>
                    <Link
                      to="/signup"
                      className="inline-flex min-h-11 items-center rounded-md bg-forest px-5 text-sm font-medium text-paper"
                    >
                      Create your account
                    </Link>
                    <Link
                      to="/login"
                      className="inline-flex min-h-11 items-center rounded-md border border-ink/15 bg-sheet px-5 text-sm font-medium"
                    >
                      Sign in
                    </Link>
                  </>
                )
              ) : (
                <span className="h-11 w-44 animate-pulse rounded-md bg-ink/10" />
              )}
            </div>
          </div>
          <aside className="rise rise-2 rounded-lg border border-ink/10 bg-sheet p-5 shadow-sm">
            <div className="flex items-center justify-between text-xs uppercase tracking-widest text-ink/50">
              <span>Office slip</span>
              <span>Examic Hub</span>
            </div>
            <div className="my-3 h-px bg-gold" />
            <ul className="space-y-3 text-sm">
              {[
                ["JAMB result print", "Documents"],
                ["Admission letter", "Documents"],
                ["Tutorial class", "Classes"],
                ["WAEC / NECO reprint", "Documents"],
              ].map(([name, kind]) => (
                <li key={name} className="flex items-baseline justify-between gap-3 border-b border-dashed border-ink/15 pb-2">
                  <span>{name}</span>
                  <span className="text-ink/50">{kind}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-sm text-ink/60">
              Live prices sit inside your account. The office can change them any time.
            </p>
          </aside>
        </section>

        <section className="border-y border-ink/10 bg-sheet">
          <div className="mx-auto grid max-w-5xl gap-6 px-4 py-10 sm:grid-cols-3">
            {LANES.map(({ icon: Icon, title, body }, index) => (
              <article key={title} className={index === 1 ? "rise rise-2" : index === 2 ? "rise rise-3" : "rise"}>
                <Icon className="text-forest" strokeWidth={1.75} />
                <h2 className="mt-3 font-display text-2xl">{title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink/70">{body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 py-12">
          <h2 className="font-display text-3xl">How a request moves</h2>
          <ol className="mt-6 grid gap-4 md:grid-cols-3">
            {STEPS.map((step) => (
              <li key={step.n} className="rounded-lg border border-ink/10 bg-sheet p-5">
                <span className="font-display text-2xl text-gold">{step.n}</span>
                <h3 className="mt-2 text-xl">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/70">{step.body}</p>
              </li>
            ))}
          </ol>
          <p className="mt-6 flex items-start gap-2 text-sm text-ink/70">
            <MessageCircle className="mt-0.5 shrink-0 text-forest" size={18} />
            Nothing is marked done until the office has seen your receipt. You can follow the status
            from your portal.
          </p>
        </section>
      </main>
    </Shell>
  );
}
