import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { Button, Field, TextInput, messageOf } from "@/components/ui";
import { emailAuth } from "@/lib/email-auth";
import { compressImage } from "@/lib/images";
import { updateProfile } from "@/lib/portal.functions";

export const Route = createFileRoute("/signup")({
  component: SignupPage,
  head: () => ({ meta: [{ title: "Create account · Examic Hub" }] }),
});

function SignupPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onPhoto(file: File | undefined) {
    if (!file) return;
    setError(null);
    try {
      setAvatar(await compressImage(file, 720));
    } catch (err) {
      setAvatar(null);
      setError(messageOf(err));
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (fullName.trim().length < 2) {
      setError("Enter your full name");
      return;
    }
    if (password.length < 8) {
      setError("Use at least 8 characters for the password");
      return;
    }
    if (!avatar) {
      setError("Add a profile photo");
      return;
    }
    setBusy(true);
    try {
      await emailAuth("sign-up", {
        email: email.trim(),
        password,
        name: fullName.trim(),
      });
      await updateProfile({
        data: { fullName: fullName.trim(), avatar, whatsapp: null },
      });
      window.location.assign("/portal");
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <Shell>
      <main className="mx-auto grid max-w-5xl gap-8 px-4 py-10 lg:grid-cols-2">
        <section>
          <p className="text-xs font-medium uppercase tracking-widest text-forest">New student</p>
          <h1 className="mt-2 font-display text-4xl">Create your account.</h1>
          <p className="mt-3 max-w-md text-ink/70">
            Your name, email, and photo stay on your profile. The office uses them to match a
            payment to the right person.
          </p>
        </section>
        <form onSubmit={onSubmit} className="space-y-4 rounded-lg border border-ink/10 bg-sheet p-5">
          <div className="flex items-center gap-4">
            {avatar ? (
              <img src={avatar} alt="" className="h-16 w-16 rounded-full object-cover" />
            ) : (
              <span className="grid h-16 w-16 place-items-center rounded-full bg-forest/10 font-display text-xl text-forest">
                Eh
              </span>
            )}
            <Field label="Profile photo">
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-forest file:px-3 file:text-sm file:text-paper"
                onChange={(e) => void onPhoto(e.target.files?.[0])}
              />
            </Field>
          </div>
          <Field label="Full name">
            <TextInput
              required
              autoComplete="name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </Field>
          <Field label="Email">
            <TextInput
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          <Field label="Password" hint="At least 8 characters.">
            <TextInput
              type="password"
              required
              autoComplete="new-password"
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          {error ? <p className="text-sm">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Creating account…" : "Create account"}
          </Button>
          <p className="text-sm text-ink/70">
            Already registered?{" "}
            <Link to="/login" className="font-medium text-forest underline-offset-4 hover:underline">
              Sign in
            </Link>
          </p>
        </form>
      </main>
    </Shell>
  );
}
