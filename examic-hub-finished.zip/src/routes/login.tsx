import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { Button, Field, TextInput, messageOf } from "@/components/ui";
import { emailAuth } from "@/lib/email-auth";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ensurePortal, whoAmI } from "@/lib/portal.functions";

export const Route = createFileRoute("/login")({
  loader: () => ensurePortal(),
  component: LoginPage,
  head: () => ({ meta: [{ title: "Sign in · Examic Hub" }] }),
});

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!mounted || !user) {
      setRole(null);
      return;
    }
    let cancelled = false;
    whoAmI()
      .then((me) => {
        if (!cancelled) setRole(me.role);
      })
      .catch(() => {
        if (!cancelled) setRole(null);
      });
    return () => {
      cancelled = true;
    };
  }, [mounted, user?.id]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await emailAuth("sign-in", { email: email.trim(), password });
      const me = await whoAmI();
      window.location.assign(me.role === "admin" ? "/admin" : "/portal");
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <Shell>
      <main className="mx-auto grid max-w-5xl gap-8 px-4 py-10 lg:grid-cols-2">
        <section>
          <p className="text-xs font-medium uppercase tracking-widest text-forest">Sign in</p>
          <h1 className="mt-2 font-display text-4xl">Welcome back.</h1>
          <p className="mt-3 max-w-md text-ink/70">
            Students use the email they registered with. Office staff sign in with the consult
            email to manage services, bank details, and receipts.
          </p>
          {mounted && !isPending && user ? (
            <p className="mt-4 rounded-md border border-ink/10 bg-sheet px-4 py-3 text-sm">
              You are signed in as {user.primaryEmail ?? user.displayName}.{" "}
              <Link to={role === "admin" ? "/admin" : "/portal"} className="font-medium text-forest underline-offset-4 hover:underline">
                Continue
              </Link>
            </p>
          ) : null}
        </section>
        <form onSubmit={onSubmit} className="space-y-4 rounded-lg border border-ink/10 bg-sheet p-5">
          <Field label="Email">
            <TextInput
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          <Field label="Password">
            <TextInput
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          {error ? <p className="text-sm text-ink">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </Button>
          <p className="text-sm text-ink/70">
            New student?{" "}
            <Link to="/signup" className="font-medium text-forest underline-offset-4 hover:underline">
              Create an account
            </Link>
          </p>
        </form>
      </main>
    </Shell>
  );
}
