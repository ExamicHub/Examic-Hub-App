import { useEffect, useMemo, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Shell } from "@/components/shell";
import {
  Button,
  Field,
  PageSkeleton,
  StatusPill,
  TextArea,
  TextInput,
  messageOf,
} from "@/components/ui";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  naira,
  ORDER_STATUSES,
  PLACEHOLDER_ACCOUNT,
  whatsappHref,
  type OrderStatus,
} from "@/lib/portal-shared";
import {
  deleteService,
  fetchReceipt,
  getAdminHome,
  updateOrder,
  updatePayment,
  upsertService,
} from "@/lib/portal.functions";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "Office · Examic Hub" }] }),
});

type AdminHome = Awaited<ReturnType<typeof getAdminHome>>;
type ServiceDraft = {
  id: number | null;
  title: string;
  description: string;
  priceNaira: string;
  category: string;
  active: boolean;
};

const EMPTY_SERVICE: ServiceDraft = {
  id: null,
  title: "",
  description: "",
  priceNaira: "",
  category: "Documents",
  active: true,
};

function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  const [home, setHome] = useState<AdminHome | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<"requests" | "services" | "account">("requests");
  const [filter, setFilter] = useState<"all" | OrderStatus>("all");

  useEffect(() => setMounted(true), []);

  async function reload() {
    setHome(await getAdminHome());
  }

  useEffect(() => {
    if (!mounted || !user) return;
    let cancelled = false;
    getAdminHome()
      .then((next) => {
        if (!cancelled) setHome(next);
      })
      .catch((err) => {
        if (!cancelled) setError(messageOf(err));
      });
    return () => {
      cancelled = true;
    };
  }, [mounted, user?.id]);

  const visible = useMemo(() => {
    if (!home) return [];
    if (filter === "all") return home.orders;
    return home.orders.filter((order) => order.status === filter);
  }, [home, filter]);

  if (!mounted || isPending || (user && !home && !error)) {
    return (
      <Shell>
        <PageSkeleton />
      </Shell>
    );
  }
  if (!user) return <RedirectToSignIn />;
  if (!home) {
    return (
      <Shell>
        <main className="mx-auto max-w-lg px-4 py-16 text-center">
          <h1 className="font-display text-4xl">Office desk</h1>
          <p className="mt-3 text-ink/70">
            {error === "Forbidden"
              ? "This desk is only for the office account. Sign in with the consult email."
              : (error ?? "Could not open the office.")}
          </p>
          <Link
            to="/login"
            className="mt-6 inline-flex min-h-11 items-center rounded-md bg-forest px-4 text-sm font-medium text-paper"
          >
            Staff sign in
          </Link>
        </main>
      </Shell>
    );
  }

  const open = home.orders.filter((order) => order.status === "pending" || order.status === "confirmed").length;

  return (
    <Shell>
      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="text-xs font-medium uppercase tracking-widest text-forest">Office</p>
        <h1 className="mt-2 font-display text-4xl">Examic Hub desk</h1>
        <dl className="mt-6 grid grid-cols-3 gap-3">
          {[
            ["Open", open],
            ["Services", home.services.filter((service) => service.active).length],
            ["Done", home.orders.filter((order) => order.status === "completed").length],
          ].map(([label, value]) => (
            <div key={String(label)} className="rounded-lg border border-ink/10 bg-sheet px-4 py-3">
              <dt className="text-xs uppercase tracking-widest text-ink/50">{label}</dt>
              <dd className="mt-1 font-display text-3xl tabular-nums">{value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-6 flex flex-wrap gap-2">
          {(
            [
              ["requests", "Requests"],
              ["services", "Services"],
              ["account", "Bank account"],
            ] as const
          ).map(([id, label]) => (
            <Button key={id} variant={tab === id ? "primary" : "line"} onClick={() => setTab(id)}>
              {label}
            </Button>
          ))}
        </div>

        {tab === "requests" ? (
          <section className="mt-6 space-y-3">
            <div className="flex flex-wrap gap-2">
              <FilterChip current={filter} value="all" onPick={setFilter} label="All" />
              {ORDER_STATUSES.map((status) => (
                <FilterChip key={status} current={filter} value={status} onPick={setFilter} label={status} />
              ))}
            </div>
            {visible.length === 0 ? (
              <p className="rounded-lg border border-dashed border-ink/20 p-6 text-sm text-ink/70">
                No requests in this list.
              </p>
            ) : (
              visible.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  onChanged={async () => {
                    await reload();
                  }}
                />
              ))
            )}
          </section>
        ) : null}

        {tab === "services" ? (
          <ServicesPanel
            services={home.services}
            onChanged={async () => {
              toast.success("Services updated");
              await reload();
            }}
          />
        ) : null}

        {tab === "account" ? (
          <AccountPanel
            payment={home.payment}
            onChanged={async () => {
              toast.success("Bank details saved");
              await reload();
            }}
          />
        ) : null}
      </main>
    </Shell>
  );
}

function FilterChip({
  current,
  value,
  label,
  onPick,
}: {
  current: string;
  value: string;
  label: string;
  onPick: (value: "all" | OrderStatus) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onPick(value as "all" | OrderStatus)}
      className={
        current === value
          ? "min-h-11 rounded-full bg-ink px-3 text-sm text-paper"
          : "min-h-11 rounded-full border border-ink/15 bg-sheet px-3 text-sm capitalize"
      }
    >
      {label}
    </button>
  );
}

function OrderCard({
  order,
  onChanged,
}: {
  order: AdminHome["orders"][number];
  onChanged: () => Promise<void>;
}) {
  const [status, setStatus] = useState<OrderStatus>(order.status);
  const [adminNote, setAdminNote] = useState(order.adminNote);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    try {
      await updateOrder({ data: { id: order.id, status, adminNote } });
      toast.success("Request updated");
      await onChanged();
    } catch (err) {
      toast.error(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="rounded-lg border border-ink/10 bg-sheet p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl">{order.serviceTitle}</h2>
          <p className="mt-1 text-sm">
            {order.studentName} · <span className="break-all">{order.studentEmail}</span>
          </p>
          <p className="mt-1 text-sm tabular-nums text-ink/70">
            {naira(order.priceNaira)} · {formatWhen(order.createdAt)}
          </p>
        </div>
        <StatusPill status={order.status} />
      </div>
      {order.note ? <p className="mt-3 text-sm text-ink/75">Student note: {order.note}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <a
          className="inline-flex min-h-11 items-center rounded-md bg-forest px-3 text-sm font-medium text-paper"
          href={whatsappHref(order.whatsapp)}
          target="_blank"
          rel="noreferrer"
        >
          WhatsApp {order.whatsapp}
        </a>
        <Button
          variant="line"
          disabled={busy}
          onClick={() => {
            if (receipt) {
              setReceipt(null);
              return;
            }
            setBusy(true);
            fetchReceipt({ data: order.id })
              .then((row) => setReceipt(row.receipt))
              .catch((err) => toast.error(messageOf(err)))
              .finally(() => setBusy(false));
          }}
        >
          {receipt ? "Hide receipt" : "View receipt"}
        </Button>
      </div>
      {receipt ? (
        <img src={receipt} alt="Payment receipt" className="mt-3 max-h-80 w-full rounded-md object-contain bg-paper" />
      ) : null}
      <div className="mt-4 grid gap-3 sm:grid-cols-[12rem_1fr]">
        <Field label="Status">
          <select
            className="min-h-11 w-full rounded-md border border-ink/15 bg-sheet px-3 text-base"
            value={status}
            onChange={(e) => setStatus(e.target.value as OrderStatus)}
          >
            {ORDER_STATUSES.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Note to the student">
          <TextInput value={adminNote} onChange={(e) => setAdminNote(e.target.value)} />
        </Field>
      </div>
      <Button className="mt-3" disabled={busy} onClick={() => void save()}>
        {busy ? "Saving…" : "Save request"}
      </Button>
    </article>
  );
}

function ServicesPanel({
  services,
  onChanged,
}: {
  services: AdminHome["services"];
  onChanged: () => Promise<void>;
}) {
  const [draft, setDraft] = useState<ServiceDraft>(EMPTY_SERVICE);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await upsertService({
        data: {
          id: draft.id,
          title: draft.title,
          description: draft.description,
          priceNaira: Number(draft.priceNaira),
          category: draft.category,
          active: draft.active,
        },
      });
      setDraft(EMPTY_SERVICE);
      await onChanged();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_1fr]">
      <form onSubmit={onSubmit} className="space-y-3 rounded-lg border border-ink/10 bg-sheet p-5">
        <h2 className="font-display text-2xl">{draft.id ? "Edit service" : "Add a service"}</h2>
        <Field label="Name">
          <TextInput value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} required />
        </Field>
        <Field label="Description">
          <TextArea
            value={draft.description}
            onChange={(e) => setDraft({ ...draft, description: e.target.value })}
            required
          />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Price (₦)">
            <TextInput
              inputMode="numeric"
              value={draft.priceNaira}
              onChange={(e) => setDraft({ ...draft, priceNaira: e.target.value.replace(/[^\d]/g, "") })}
              required
            />
          </Field>
          <Field label="Category">
            <TextInput
              value={draft.category}
              onChange={(e) => setDraft({ ...draft, category: e.target.value })}
              required
            />
          </Field>
        </div>
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={draft.active}
            onChange={(e) => setDraft({ ...draft, active: e.target.checked })}
          />
          Visible to students
        </label>
        {error ? <p className="text-sm">{error}</p> : null}
        <div className="flex gap-2">
          <Button type="submit" disabled={busy}>
            {busy ? "Saving…" : draft.id ? "Update service" : "Add service"}
          </Button>
          {draft.id ? (
            <Button type="button" variant="ghost" onClick={() => setDraft(EMPTY_SERVICE)}>
              Cancel
            </Button>
          ) : null}
        </div>
      </form>
      <ul className="space-y-3">
        {services.map((service) => (
          <li key={service.id} className="rounded-lg border border-ink/10 bg-sheet p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-widest text-ink/50">{service.category}</p>
                <h3 className="text-xl">{service.title}</h3>
                <p className="mt-1 text-sm text-ink/70">{service.description}</p>
                <p className="mt-2 font-display text-2xl tabular-nums text-gold">{naira(service.priceNaira)}</p>
                {!service.active ? <p className="mt-1 text-xs uppercase tracking-widest text-ink/50">Hidden</p> : null}
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <Button
                variant="line"
                onClick={() =>
                  setDraft({
                    id: service.id,
                    title: service.title,
                    description: service.description,
                    priceNaira: String(service.priceNaira),
                    category: service.category,
                    active: service.active,
                  })
                }
              >
                Edit
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  if (!window.confirm(`Remove “${service.title}”? Requests already made will keep their copy.`)) return;
                  void deleteService({ data: service.id })
                    .then(() => onChanged())
                    .catch((err) => toast.error(messageOf(err)));
                }}
              >
                Remove
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function AccountPanel({
  payment,
  onChanged,
}: {
  payment: AdminHome["payment"];
  onChanged: () => Promise<void>;
}) {
  const [bankName, setBankName] = useState(payment.bankName);
  const [accountName, setAccountName] = useState(payment.accountName);
  const [accountNumber, setAccountNumber] = useState(payment.accountNumber);
  const [note, setNote] = useState(payment.note);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const placeholder = payment.accountNumber === PLACEHOLDER_ACCOUNT;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await updatePayment({ data: { bankName, accountName, accountNumber, note } });
      await onChanged();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 max-w-xl space-y-3 rounded-lg border border-ink/10 bg-sheet p-5">
      <h2 className="font-display text-2xl">Account students pay into</h2>
      {placeholder ? (
        <p className="rounded-md bg-gold/20 px-3 py-2 text-sm">
          This is a placeholder account. Replace it with the real office account before anyone pays.
        </p>
      ) : (
        <p className="text-sm text-ink/70">Students see these details when they request a service.</p>
      )}
      <Field label="Bank">
        <TextInput value={bankName} onChange={(e) => setBankName(e.target.value)} required />
      </Field>
      <Field label="Account name">
        <TextInput value={accountName} onChange={(e) => setAccountName(e.target.value)} required />
      </Field>
      <Field label="Account number" hint="10 digits.">
        <TextInput
          inputMode="numeric"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value.replace(/[^\d]/g, "").slice(0, 10))}
          required
        />
      </Field>
      <Field label="Note shown with the account">
        <TextArea value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      {error ? <p className="text-sm">{error}</p> : null}
      <Button type="submit" disabled={busy}>
        {busy ? "Saving…" : "Save account"}
      </Button>
    </form>
  );
}

function formatWhen(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-NG", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}
