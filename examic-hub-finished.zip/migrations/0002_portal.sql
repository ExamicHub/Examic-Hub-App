-- Examic Hub student portal: profiles, services, payments, and requests.

create table if not exists profiles (
  user_id    text primary key,
  email      text not null,
  full_name  text not null,
  avatar     text,
  whatsapp   text,
  role       text not null default 'student' check (role in ('student', 'admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists services (
  id          serial primary key,
  title       text not null,
  description text not null,
  price_naira integer not null check (price_naira >= 0 and price_naira <= 5000000),
  category    text not null,
  active      boolean not null default true,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists payment_settings (
  id             integer primary key check (id = 1),
  bank_name      text not null,
  account_name   text not null,
  account_number text not null,
  note           text not null default ''
);

create table if not exists orders (
  id            serial primary key,
  user_id       text not null,
  service_id    integer references services (id) on delete restrict,
  service_title text not null,
  price_naira   integer not null,
  whatsapp      text not null,
  receipt       text not null,
  note          text not null default '',
  status        text not null default 'pending' check (status in ('pending', 'confirmed', 'completed', 'rejected')),
  admin_note    text not null default '',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists orders_user_id_idx on orders (user_id);
create index if not exists orders_status_idx on orders (status);

create table if not exists portal_flags (
  key   text primary key,
  value text not null
);
