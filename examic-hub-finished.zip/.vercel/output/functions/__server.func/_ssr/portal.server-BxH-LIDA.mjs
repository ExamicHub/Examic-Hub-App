import { i as assertWhatsapp, o as isMalpracticeCopy, r as assertImageData, t as ORDER_STATUSES } from "./portal-shared-BG4-ZQHK.mjs";
import { r as getSql } from "./db-Cy8KniRL.mjs";
import { ensureSeed } from "./seed.server-B2VMP_8w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal.server-BxH-LIDA.js
var ADMIN_EMAIL = "examichubeduconsult@gmail.com";
function stamp(value) {
	if (value instanceof Date) return value.toISOString();
	return typeof value === "string" ? value : "";
}
function asStatus(value) {
	return ORDER_STATUSES.includes(value) ? value : "pending";
}
async function sqlReady() {
	await ensureSeed();
	return getSql();
}
async function requireActor(userId) {
	const sql = await sqlReady();
	const user = (await sql`
    select id, email, name from "user" where id = ${userId} limit 1
  `)[0];
	if (!user) throw new Error("Account not found");
	const email = user.email.toLowerCase();
	if (email === ADMIN_EMAIL) await sql`
      insert into profiles (user_id, email, full_name, role)
      values (${userId}, ${email}, ${user.name}, 'admin')
      on conflict (user_id) do update set role = 'admin', email = ${email}
    `;
	const profile = (await sql`
    select user_id, email, full_name, avatar, whatsapp, role
    from profiles where user_id = ${userId} limit 1
  `)[0];
	const role = email === ADMIN_EMAIL || profile?.role === "admin" ? "admin" : "student";
	return {
		userId,
		email,
		name: profile?.full_name || user.name,
		avatar: profile?.avatar ?? null,
		whatsapp: profile?.whatsapp ?? null,
		role,
		hasProfile: Boolean(profile)
	};
}
function mapService(row) {
	return {
		id: Number(row.id),
		title: row.title,
		description: row.description,
		priceNaira: Number(row.price_naira),
		category: row.category,
		active: Boolean(row.active)
	};
}
async function readPayment(sql) {
	const row = (await sql`
    select bank_name, account_name, account_number, note
    from payment_settings where id = 1
  `)[0];
	return {
		bankName: row?.bank_name ?? "",
		accountName: row?.account_name ?? "",
		accountNumber: row?.account_number ?? "",
		note: row?.note ?? ""
	};
}
async function loadWho(userId) {
	const actor = await requireActor(userId);
	return {
		role: actor.role,
		name: actor.name,
		email: actor.email,
		avatar: actor.avatar,
		hasProfile: actor.hasProfile
	};
}
async function loadPortal(userId) {
	const actor = await requireActor(userId);
	const sql = await getSql();
	const services = await sql`
    select id, title, description, price_naira, category, active
    from services
    where active = true
    order by sort_order, id
  `;
	const orders = await sql`
    select id, service_title, price_naira, whatsapp, note, status, admin_note, created_at
    from orders
    where user_id = ${userId}
    order by created_at desc
  `;
	return {
		actor: {
			name: actor.name,
			email: actor.email,
			avatar: actor.avatar,
			whatsapp: actor.whatsapp,
			role: actor.role,
			hasProfile: actor.hasProfile
		},
		services: services.map(mapService),
		payment: await readPayment(sql),
		orders: orders.map((row) => ({
			id: Number(row.id),
			serviceTitle: row.service_title,
			priceNaira: Number(row.price_naira),
			whatsapp: row.whatsapp,
			note: row.note,
			status: asStatus(row.status),
			adminNote: row.admin_note,
			createdAt: stamp(row.created_at)
		}))
	};
}
async function saveProfile(userId, input) {
	const actor = await requireActor(userId);
	const fullName = input.fullName.trim();
	if (fullName.length < 2 || fullName.length > 80) throw new Error("Enter your full name");
	let avatar = actor.avatar;
	if (input.avatar) avatar = assertImageData(input.avatar, "Profile photo");
	if (actor.role !== "admin" && !avatar) throw new Error("Add a profile photo");
	let whatsapp = actor.whatsapp;
	if (input.whatsapp && input.whatsapp.trim()) whatsapp = assertWhatsapp(input.whatsapp);
	const sql = await getSql();
	await sql`
    insert into profiles (user_id, email, full_name, avatar, whatsapp, role)
    values (${userId}, ${actor.email}, ${fullName}, ${avatar}, ${whatsapp}, ${actor.role})
    on conflict (user_id) do update set
      full_name = ${fullName},
      avatar = ${avatar},
      whatsapp = ${whatsapp},
      email = ${actor.email},
      updated_at = now()
  `;
	await sql`
    update "user" set name = ${fullName}, "updatedAt" = now() where id = ${userId}
  `;
	return { ok: true };
}
async function createOrder(userId, input) {
	const actor = await requireActor(userId);
	if (!actor.hasProfile || actor.name.trim().length < 2) throw new Error("Add your full name before requesting a service");
	if (actor.role !== "admin" && !actor.avatar) throw new Error("Add a profile photo before requesting a service");
	const whatsapp = assertWhatsapp(input.whatsapp);
	const receipt = assertImageData(input.receipt, "Payment receipt");
	const note = input.note.trim().slice(0, 500);
	const serviceId = Number(input.serviceId);
	if (!Number.isInteger(serviceId)) throw new Error("Choose a service");
	const sql = await getSql();
	const service = (await sql`
    select id, title, price_naira, active from services where id = ${serviceId} limit 1
  `)[0];
	if (!service || !service.active) throw new Error("That service is not available");
	const inserted = await sql`
    insert into orders (
      user_id, service_id, service_title, price_naira, whatsapp, receipt, note
    )
    values (
      ${userId},
      ${service.id},
      ${service.title},
      ${service.price_naira},
      ${whatsapp},
      ${receipt},
      ${note}
    )
    returning id
  `;
	return { id: Number(inserted[0]?.id ?? 0) };
}
async function requireAdmin(userId) {
	const actor = await requireActor(userId);
	if (actor.role !== "admin") throw new Error("Forbidden");
	return actor;
}
async function loadAdmin(userId) {
	await requireAdmin(userId);
	const sql = await getSql();
	const services = await sql`
    select id, title, description, price_naira, category, active
    from services
    order by sort_order, id
  `;
	const orders = await sql`
    select
      o.id,
      o.service_title,
      o.price_naira,
      o.whatsapp,
      o.note,
      o.status,
      o.admin_note,
      o.created_at,
      coalesce(p.full_name, u.name) as student_name,
      u.email as student_email
    from orders o
    join "user" u on u.id = o.user_id
    left join profiles p on p.user_id = o.user_id
    order by o.created_at desc
    limit 100
  `;
	return {
		services: services.map(mapService),
		payment: await readPayment(sql),
		orders: orders.map((row) => ({
			id: Number(row.id),
			serviceTitle: row.service_title,
			priceNaira: Number(row.price_naira),
			whatsapp: row.whatsapp,
			note: row.note,
			status: asStatus(row.status),
			adminNote: row.admin_note,
			createdAt: stamp(row.created_at),
			studentName: row.student_name,
			studentEmail: row.student_email
		}))
	};
}
function cleanServiceCopy(title, description, category) {
	const blob = `${title}\n${description}\n${category}`;
	if (isMalpracticeCopy(blob)) throw new Error("Exam malpractice services — including runz, expo, or leaked questions — cannot be listed.");
}
async function saveService(userId, input) {
	await requireAdmin(userId);
	const title = input.title.trim();
	const description = input.description.trim();
	const category = input.category.trim();
	if (title.length < 3 || title.length > 80) throw new Error("Give the service a clear name");
	if (description.length < 8 || description.length > 400) throw new Error("Add a short description");
	if (category.length < 2 || category.length > 40) throw new Error("Add a category");
	const price = Number(input.priceNaira);
	if (!Number.isInteger(price) || price < 0 || price > 5e6) throw new Error("Enter a price in naira");
	cleanServiceCopy(title, description, category);
	const sql = await getSql();
	if (input.id) {
		const updated = await sql`
      update services set
        title = ${title},
        description = ${description},
        price_naira = ${price},
        category = ${category},
        active = ${input.active}
      where id = ${input.id}
      returning id
    `;
		if (!updated[0]) throw new Error("Service not found");
		return { id: Number(updated[0].id) };
	}
	const next = await sql`select coalesce(max(sort_order), 0)::int as n from services`;
	const inserted = await sql`
    insert into services (title, description, price_naira, category, active, sort_order)
    values (${title}, ${description}, ${price}, ${category}, ${input.active}, ${(next[0]?.n ?? 0) + 1})
    returning id
  `;
	return { id: Number(inserted[0]?.id ?? 0) };
}
async function removeService(userId, id) {
	await requireAdmin(userId);
	const sql = await getSql();
	if (((await sql`
    select count(*)::int as n from orders where service_id = ${id}
  `)[0]?.n ?? 0) > 0) {
		await sql`update services set active = false where id = ${id}`;
		return { archived: true };
	}
	await sql`delete from services where id = ${id}`;
	return { archived: false };
}
async function savePayment(userId, input) {
	await requireAdmin(userId);
	const bankName = input.bankName.trim();
	const accountName = input.accountName.trim();
	const accountNumber = input.accountNumber.replace(/\s/g, "");
	const note = input.note.trim().slice(0, 280);
	if (bankName.length < 2 || bankName.length > 60) throw new Error("Enter the bank name");
	if (accountName.length < 2 || accountName.length > 80) throw new Error("Enter the account name");
	if (!/^\d{10}$/.test(accountNumber)) throw new Error("Nigerian account numbers are 10 digits");
	await (await getSql())`
    insert into payment_settings (id, bank_name, account_name, account_number, note)
    values (1, ${bankName}, ${accountName}, ${accountNumber}, ${note})
    on conflict (id) do update set
      bank_name = ${bankName},
      account_name = ${accountName},
      account_number = ${accountNumber},
      note = ${note}
  `;
	return { ok: true };
}
async function setOrderStatus(userId, input) {
	await requireAdmin(userId);
	if (!ORDER_STATUSES.includes(input.status)) throw new Error("Unknown status");
	const note = input.adminNote.trim().slice(0, 400);
	if (!(await (await getSql())`
    update orders
    set status = ${input.status}, admin_note = ${note}, updated_at = now()
    where id = ${input.id}
    returning id
  `)[0]) throw new Error("Request not found");
	return { ok: true };
}
async function readReceipt(userId, orderId) {
	const actor = await requireActor(userId);
	const row = (await (await getSql())`
    select user_id, receipt from orders where id = ${orderId} limit 1
  `)[0];
	if (!row) throw new Error("Receipt not found");
	if (actor.role !== "admin" && row.user_id !== userId) throw new Error("Receipt not found");
	return { receipt: row.receipt };
}
//#endregion
export { createOrder, loadAdmin, loadPortal, loadWho, readReceipt, removeService, savePayment, saveProfile, saveService, setOrderStatus };
