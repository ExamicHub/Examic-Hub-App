import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as FileText, i as GraduationCap, n as MessageCircle, r as Landmark } from "../_libs/lucide-react.mjs";
import { r as useCurrentUserState, t as Shell } from "./shell-BebHXyQF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-dyFU2kWk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		n: "01",
		title: "Open an account",
		body: "Add your full name, email, and a profile photo so the office knows who is asking."
	},
	{
		n: "02",
		title: "Pay the published account",
		body: "Each service shows the current price and the bank details the office is using."
	},
	{
		n: "03",
		title: "Send receipt and WhatsApp",
		body: "Upload a photo of the transfer alert and the number we should reach you on."
	}
];
var LANES = [
	{
		icon: FileText,
		title: "Document printing",
		body: "JAMB result slips, admission letters, and WAEC or NECO result reprints."
	},
	{
		icon: GraduationCap,
		title: "Tutorial classes",
		body: "Pay for lesson support and tell us the subjects in your request note."
	},
	{
		icon: Landmark,
		title: "Registration help",
		body: "JAMB registration, O'Level upload, and change of institution or course."
	}
];
function Home() {
	const { user, isPending } = useCurrentUserState();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-5xl gap-8 px-4 py-10 sm:py-16 lg:grid-cols-[1.2fr_0.8fr] lg:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-forest",
						children: "Student portal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-xl font-display text-4xl leading-tight text-ink sm:text-5xl",
						children: "Your exam paperwork, without the queue."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-lg text-lg leading-relaxed text-ink/75",
						children: "Examic Hub Edu Consult takes JAMB prints, tutorial payments, and registration support off the corridor. You request it here. We confirm the receipt and reply on WhatsApp."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: mounted && !isPending ? user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/portal",
							className: "inline-flex min-h-11 items-center rounded-md bg-forest px-5 text-sm font-medium text-paper",
							children: "Open my portal"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							className: "inline-flex min-h-11 items-center rounded-md bg-forest px-5 text-sm font-medium text-paper",
							children: "Create your account"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "inline-flex min-h-11 items-center rounded-md border border-ink/15 bg-sheet px-5 text-sm font-medium",
							children: "Sign in"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-11 w-44 animate-pulse rounded-md bg-ink/10" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rise rise-2 rounded-lg border border-ink/10 bg-sheet p-5 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs uppercase tracking-widest text-ink/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Office slip" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Examic Hub" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3 text-sm",
						children: [
							["JAMB result print", "Documents"],
							["Admission letter", "Documents"],
							["Tutorial class", "Classes"],
							["WAEC / NECO reprint", "Documents"]
						].map(([name, kind]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 border-b border-dashed border-ink/15 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ink/50",
								children: kind
							})]
						}, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-ink/60",
						children: "Live prices sit inside your account. The office can change them any time."
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-ink/10 bg-sheet",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-5xl gap-6 px-4 py-10 sm:grid-cols-3",
				children: LANES.map(({ icon: Icon, title, body }, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: index === 1 ? "rise rise-2" : index === 2 ? "rise rise-3" : "rise",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "text-forest",
							strokeWidth: 1.75
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-2xl",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-ink/70",
							children: body
						})
					]
				}, title))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-5xl px-4 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "How a request moves"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid gap-4 md:grid-cols-3",
					children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-ink/10 bg-sheet p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-gold",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 text-xl",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-ink/70",
								children: step.body
							})
						]
					}, step.n))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 flex items-start gap-2 text-sm text-ink/70",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
						className: "mt-0.5 shrink-0 text-forest",
						size: 18
					}), "Nothing is marked done until the office has seen your receipt. You can follow the status from your portal."]
				})
			]
		})
	] }) });
}
//#endregion
export { Home as component };
