import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./shell-BebHXyQF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-B1_fz_-z.js
var import_jsx_runtime = require_jsx_runtime();
var tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-50", tap, variant === "primary" && "bg-forest text-paper hover:bg-forest/90", variant === "gold" && "bg-gold text-ink hover:bg-gold/90", variant === "line" && "border border-ink/15 bg-sheet text-ink hover:bg-paper", variant === "ghost" && "text-ink hover:bg-ink/5", variant === "danger" && "border border-ink/15 bg-sheet text-ink hover:bg-ink/5", className),
		...props
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-ink/60",
				children: hint
			}) : null
		]
	});
}
var inputClass = "min-h-11 w-full rounded-md border border-ink/15 bg-sheet px-3 text-base text-ink outline-none placeholder:text-ink/40";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(inputClass, props.className)
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn(inputClass, "min-h-24 py-2", props.className)
	});
}
function PageSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-4 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 animate-pulse rounded-md bg-ink/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-lg bg-ink/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-36 animate-pulse rounded-lg bg-ink/10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-36 animate-pulse rounded-lg bg-ink/10" })]
			})
		]
	});
}
var STATUS_LABEL = {
	pending: "Awaiting check",
	confirmed: "Payment seen",
	completed: "Done",
	rejected: "Not accepted"
};
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex rounded-full px-2.5 py-1 text-xs font-medium", status === "completed" ? "bg-forest text-paper" : status === "confirmed" ? "bg-forest/10 text-forest" : status === "rejected" ? "bg-ink/10 text-ink/70" : "bg-gold/20 text-ink"),
		children: STATUS_LABEL[status] ?? status
	});
}
function messageOf(err) {
	if (err instanceof Error && err.message) return err.message;
	if (typeof err === "object" && err && "message" in err) {
		const message = err.message;
		if (typeof message === "string" && message) return message;
	}
	return "Something went wrong. Try again.";
}
//#endregion
export { TextArea as a, StatusPill as i, Field as n, TextInput as o, PageSkeleton as r, messageOf as s, Button as t };
