import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as updateProfile } from "./router-BUF_86uw.mjs";
import { t as Shell } from "./shell-BebHXyQF.mjs";
import { n as Field, o as TextInput, s as messageOf, t as Button } from "./ui-B1_fz_-z.mjs";
import { t as emailAuth } from "./email-auth-Be3BaIBm.mjs";
import { t as compressImage } from "./images-D6Z0eXSp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signup-CZ5fu2SU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SignupPage() {
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [avatar, setAvatar] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onPhoto(file) {
		if (!file) return;
		setError(null);
		try {
			setAvatar(await compressImage(file, 720));
		} catch (err) {
			setAvatar(null);
			setError(messageOf(err));
		}
	}
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		if (fullName.trim().length < 2) {
			setError("Enter your full name");
			return;
		}
		if (password.length < 8) {
			setError("Use at least 8 characters for the password");
			return;
		}
		if (!avatar) {
			setError("Add a profile photo");
			return;
		}
		setBusy(true);
		try {
			await emailAuth("sign-up", {
				email: email.trim(),
				password,
				name: fullName.trim()
			});
			await updateProfile({ data: {
				fullName: fullName.trim(),
				avatar,
				whatsapp: null
			} });
			window.location.assign("/portal");
		} catch (err) {
			setError(messageOf(err));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-5xl gap-8 px-4 py-10 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-widest text-forest",
				children: "New student"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Create your account."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-ink/70",
				children: "Your name, email, and photo stay on your profile. The office uses them to match a payment to the right person."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4 rounded-lg border border-ink/10 bg-sheet p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: avatar,
						alt: "",
						className: "h-16 w-16 rounded-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-16 w-16 place-items-center rounded-full bg-forest/10 font-display text-xl text-forest",
						children: "Eh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Profile photo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png,image/webp",
							className: "block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-forest file:px-3 file:text-sm file:text-paper",
							onChange: (e) => void onPhoto(e.target.files?.[0])
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Full name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						required: true,
						autoComplete: "name",
						value: fullName,
						onChange: (e) => setFullName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "email",
						required: true,
						autoComplete: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Password",
					hint: "At least 8 characters.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "password",
						required: true,
						autoComplete: "new-password",
						minLength: 8,
						value: password,
						onChange: (e) => setPassword(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy,
					children: busy ? "Creating account…" : "Create account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ink/70",
					children: [
						"Already registered?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "font-medium text-forest underline-offset-4 hover:underline",
							children: "Sign in"
						})
					]
				})
			]
		})]
	}) });
}
//#endregion
export { SignupPage as component };
