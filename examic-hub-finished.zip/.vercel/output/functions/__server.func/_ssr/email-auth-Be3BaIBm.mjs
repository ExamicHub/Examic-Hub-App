import { t as authClient } from "./client-BhcLuWvF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-auth-Be3BaIBm.js
var BEARER_KEY = "grok-auth.bearer-token";
function rememberToken(token) {
	if (typeof window === "undefined" || !token) return;
	try {
		window.sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
}
/**
* Email sign-in / sign-up against this app's Better Auth.
* Stores the session bearer so the live preview (partitioned cookies) stays signed in.
*/
async function emailAuth(kind, body) {
	const res = await fetch(`/api/auth/${kind}/email`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify(body)
	});
	const payload = await res.json().catch(() => null);
	if (!res.ok) throw new Error(payload?.message || "That didn't work. Check the details and try again.");
	rememberToken(res.headers.get("set-auth-token") || payload?.token || null);
	await authClient.getSession();
}
//#endregion
export { emailAuth as t };
