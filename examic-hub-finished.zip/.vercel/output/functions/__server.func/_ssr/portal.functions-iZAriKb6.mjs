import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as authMiddleware, t as ORDER_STATUSES } from "./portal-shared-BG4-ZQHK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal.functions-iZAriKb6.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/** Bootstraps the office account before anyone is signed in. No personal data. */
var ensurePortal_createServerFn_handler = createServerRpc({
	id: "0ac4331f08539394ca3514034afd8d12f80c0d7062ef09c7c0bd95618e12b557",
	name: "ensurePortal",
	filename: "src/lib/portal.functions.ts"
}, (opts) => ensurePortal.__executeServer(opts));
var ensurePortal = createServerFn({ method: "GET" }).handler(ensurePortal_createServerFn_handler, async () => {
	const { ensureSeed } = await import("./seed.server-B2VMP_8w.mjs");
	await ensureSeed();
	return { ok: true };
});
var whoAmI_createServerFn_handler = createServerRpc({
	id: "2c8dc645666a17f55dca23d19f3e9372ea6dec46f1842abb92e1cf5352b4546f",
	name: "whoAmI",
	filename: "src/lib/portal.functions.ts"
}, (opts) => whoAmI.__executeServer(opts));
var whoAmI = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(whoAmI_createServerFn_handler, async ({ context }) => {
	const { loadWho } = await import("./portal.server-BxH-LIDA.mjs");
	return loadWho(context.userId);
});
var getPortalHome_createServerFn_handler = createServerRpc({
	id: "0253184b9f13ff5ce6b502a3c98b39a5a7b1bef16a18aad8823a8a37d649a9b9",
	name: "getPortalHome",
	filename: "src/lib/portal.functions.ts"
}, (opts) => getPortalHome.__executeServer(opts));
var getPortalHome = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPortalHome_createServerFn_handler, async ({ context }) => {
	const { loadPortal } = await import("./portal.server-BxH-LIDA.mjs");
	return loadPortal(context.userId);
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "10b4aeaed5f9837dfa3d0f358827e86aab5bd1efc31235d3602b9cc9d9f7bafe",
	name: "updateProfile",
	filename: "src/lib/portal.functions.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.fullName !== "string") throw new Error("Enter your full name");
	return {
		fullName: input.fullName,
		avatar: typeof input.avatar === "string" ? input.avatar : null,
		whatsapp: typeof input.whatsapp === "string" ? input.whatsapp : null
	};
}).middleware([authMiddleware]).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const { saveProfile } = await import("./portal.server-BxH-LIDA.mjs");
	return saveProfile(context.userId, data);
});
var requestService_createServerFn_handler = createServerRpc({
	id: "9ad2e730dc80178f3f9bd1aa14306653e9f617ee149a808cbbdecb5db7637951",
	name: "requestService",
	filename: "src/lib/portal.functions.ts"
}, (opts) => requestService.__executeServer(opts));
var requestService = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.receipt !== "string" || typeof input.whatsapp !== "string") throw new Error("Add your receipt and WhatsApp number");
	return {
		serviceId: Number(input.serviceId),
		whatsapp: input.whatsapp,
		receipt: input.receipt,
		note: typeof input.note === "string" ? input.note : ""
	};
}).middleware([authMiddleware]).handler(requestService_createServerFn_handler, async ({ context, data }) => {
	const { createOrder } = await import("./portal.server-BxH-LIDA.mjs");
	return createOrder(context.userId, data);
});
var getAdminHome_createServerFn_handler = createServerRpc({
	id: "00fb5a9579d938c6ddbea7358074c8c32a5cd159da27a157961be352293cf56e",
	name: "getAdminHome",
	filename: "src/lib/portal.functions.ts"
}, (opts) => getAdminHome.__executeServer(opts));
var getAdminHome = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getAdminHome_createServerFn_handler, async ({ context }) => {
	const { loadAdmin } = await import("./portal.server-BxH-LIDA.mjs");
	return loadAdmin(context.userId);
});
var upsertService_createServerFn_handler = createServerRpc({
	id: "ba26c0ef926f88f51c8854a0a68b97f4f815be692027964953cfb805b169090d",
	name: "upsertService",
	filename: "src/lib/portal.functions.ts"
}, (opts) => upsertService.__executeServer(opts));
var upsertService = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(upsertService_createServerFn_handler, async ({ context, data }) => {
	const { saveService } = await import("./portal.server-BxH-LIDA.mjs");
	return saveService(context.userId, data);
});
var deleteService_createServerFn_handler = createServerRpc({
	id: "3e6d3ab2a585440b58ab88db44df46aae723c08af03f2298f09d64f3c53e6345",
	name: "deleteService",
	filename: "src/lib/portal.functions.ts"
}, (opts) => deleteService.__executeServer(opts));
var deleteService = createServerFn({ method: "POST" }).validator((id) => {
	const n = Number(id);
	if (!Number.isInteger(n)) throw new Error("Unknown service");
	return n;
}).middleware([authMiddleware]).handler(deleteService_createServerFn_handler, async ({ context, data }) => {
	const { removeService } = await import("./portal.server-BxH-LIDA.mjs");
	return removeService(context.userId, data);
});
var updatePayment_createServerFn_handler = createServerRpc({
	id: "9aadcae4279d873b173d765a9ef61115df91c5b48a54bbd3d27abe06a97ed339",
	name: "updatePayment",
	filename: "src/lib/portal.functions.ts"
}, (opts) => updatePayment.__executeServer(opts));
var updatePayment = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(updatePayment_createServerFn_handler, async ({ context, data }) => {
	const { savePayment } = await import("./portal.server-BxH-LIDA.mjs");
	return savePayment(context.userId, data);
});
var updateOrder_createServerFn_handler = createServerRpc({
	id: "c237f1330f8ea772bdd9a36f8ed61a3a47aded7da7ecb66e7621ab4fd98cae35",
	name: "updateOrder",
	filename: "src/lib/portal.functions.ts"
}, (opts) => updateOrder.__executeServer(opts));
var updateOrder = createServerFn({ method: "POST" }).validator((input) => {
	if (!ORDER_STATUSES.includes(input.status)) throw new Error("Unknown status");
	return {
		id: Number(input.id),
		status: input.status,
		adminNote: input.adminNote ?? ""
	};
}).middleware([authMiddleware]).handler(updateOrder_createServerFn_handler, async ({ context, data }) => {
	const { setOrderStatus } = await import("./portal.server-BxH-LIDA.mjs");
	return setOrderStatus(context.userId, data);
});
var fetchReceipt_createServerFn_handler = createServerRpc({
	id: "d6dee530104fd7f5a6a1f76ec764cae2f3c2175c0fdf186dd1dd3ffcc85f77ce",
	name: "fetchReceipt",
	filename: "src/lib/portal.functions.ts"
}, (opts) => fetchReceipt.__executeServer(opts));
var fetchReceipt = createServerFn({ method: "POST" }).validator((id) => {
	const n = Number(id);
	if (!Number.isInteger(n)) throw new Error("Unknown request");
	return n;
}).middleware([authMiddleware]).handler(fetchReceipt_createServerFn_handler, async ({ context, data }) => {
	const { readReceipt } = await import("./portal.server-BxH-LIDA.mjs");
	return readReceipt(context.userId, data);
});
//#endregion
export { deleteService_createServerFn_handler, ensurePortal_createServerFn_handler, fetchReceipt_createServerFn_handler, getAdminHome_createServerFn_handler, getPortalHome_createServerFn_handler, requestService_createServerFn_handler, updateOrder_createServerFn_handler, updatePayment_createServerFn_handler, updateProfile_createServerFn_handler, upsertService_createServerFn_handler, whoAmI_createServerFn_handler };
