import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as whatsappHref, s as naira } from "./portal-shared-BG4-ZQHK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as getPortalHome, l as updateProfile, o as requestService, r as fetchReceipt } from "./router-BUF_86uw.mjs";
import { r as useCurrentUserState, t as Shell } from "./shell-BebHXyQF.mjs";
import { a as TextArea, i as StatusPill, n as Field, o as TextInput, r as PageSkeleton, s as messageOf, t as Button } from "./ui-B1_fz_-z.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as compressImage } from "./images-D6Z0eXSp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal-IMMUgJ0v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PortalPage() {
	const { user, isPending } = useCurrentUserState();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [home, setHome] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [picked, setPicked] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => setMounted(true), []);
	async function reload() {
		const next = await getPortalHome();
		setHome(next);
	}
	(0, import_react.useEffect)(() => {
		if (!mounted || !user) return;
		let cancelled = false;
		getPortalHome().then((next) => {
			if (!cancelled) setHome(next);
		}).catch((err) => {
			if (!cancelled) setError(messageOf(err));
		});
		return () => {
			cancelled = true;
		};
	}, [mounted, user?.id]);
	if (!mounted || isPending || user && !home && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (error || !home) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-5xl px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error ?? "Could not open your portal." })
	}) });
	const needsPhoto = home.actor.role !== "admin" && !home.actor.avatar;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl space-y-10 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-forest",
						children: "Student portal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 font-display text-4xl",
						children: [
							"Hello, ",
							home.actor.name.split(" ")[0],
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ink/65",
						children: home.actor.email
					})
				] }), home.actor.avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: home.actor.avatar,
					alt: "",
					className: "h-16 w-16 rounded-full object-cover"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileCard, {
				name: home.actor.name,
				avatar: home.actor.avatar,
				whatsapp: home.actor.whatsapp,
				needsPhoto,
				onSaved: () => {
					toast.success("Profile saved");
					return reload();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-ink/70",
					children: "Prices are set by the office. Pay the account shown, then send the receipt and the WhatsApp number we should use."
				}),
				home.services.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-lg border border-dashed border-ink/20 bg-sheet p-6 text-sm",
					children: "No services are listed right now. Check back soon."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 grid gap-4 sm:grid-cols-2",
					children: home.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col rounded-lg border border-ink/10 bg-sheet p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-ink/50",
								children: service.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 text-2xl",
								children: service.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 flex-1 text-sm leading-relaxed text-ink/70",
								children: service.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-display text-3xl tabular-nums text-gold",
								children: naira(service.priceNaira)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-4",
								onClick: () => setPicked(service),
								disabled: needsPhoto || !home.actor.hasProfile,
								children: "Request this"
							})
						]
					}, service.id))
				}),
				needsPhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-ink/70",
					children: "Add a profile photo above before you request a service."
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "My requests"
			}), home.orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink/70",
				children: "You have not requested anything yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-3",
				children: home.orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-ink/10 bg-sheet p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg",
								children: order.serviceTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm tabular-nums text-ink/70",
								children: [
									naira(order.priceNaira),
									" · ",
									formatWhen(order.createdAt)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: [
									"WhatsApp:",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "text-forest underline-offset-4 hover:underline",
										href: whatsappHref(order.whatsapp),
										target: "_blank",
										rel: "noreferrer",
										children: order.whatsapp
									})
								]
							}),
							order.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-ink/70",
								children: order.note
							}) : null,
							order.adminNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm",
								children: ["Office note: ", order.adminNote]
							}) : null
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: order.status })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptButton, { id: order.id })]
				}, order.id))
			})] })
		]
	}), picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestSheet, {
		service: picked,
		payment: home.payment,
		defaultWhatsapp: home.actor.whatsapp ?? "",
		onClose: () => setPicked(null),
		onDone: async () => {
			setPicked(null);
			toast.success("Request sent. We'll confirm the receipt and reach you on WhatsApp.");
			await reload();
		}
	}) : null] });
}
function formatWhen(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	return new Intl.DateTimeFormat("en-NG", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
function ProfileCard({ name, avatar, whatsapp, needsPhoto, onSaved }) {
	const [fullName, setFullName] = (0, import_react.useState)(name);
	const [photo, setPhoto] = (0, import_react.useState)(null);
	const [line, setLine] = (0, import_react.useState)(whatsapp ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await updateProfile({ data: {
				fullName,
				avatar: photo,
				whatsapp: line.trim() ? line : null
			} });
			setPhoto(null);
			await onSaved();
		} catch (err) {
			setError(messageOf(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-4 rounded-lg border border-ink/10 bg-sheet p-5 sm:grid-cols-[auto_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: photo || avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: photo || avatar || "",
			alt: "",
			className: "h-20 w-20 rounded-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-20 w-20 place-items-center rounded-full bg-forest/10 font-display text-2xl text-forest",
			children: name.charAt(0).toUpperCase()
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Your profile"
					}), needsPhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-gold",
						children: "Photo still needed"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: fullName,
							onChange: (e) => setFullName(e.target.value),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "WhatsApp",
						hint: "Optional here. Each request still asks for one.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "tel",
							placeholder: "0803 000 0000",
							value: line,
							onChange: (e) => setLine(e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Profile photo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/jpeg,image/png,image/webp",
						className: "block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-ink/5 file:px-3 file:text-sm",
						onChange: (e) => {
							const file = e.target.files?.[0];
							if (!file) return;
							compressImage(file, 720).then(setPhoto).catch((err) => setError(messageOf(err)));
						}
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "line",
					disabled: busy,
					children: busy ? "Saving…" : "Save profile"
				})
			]
		})]
	});
}
function RequestSheet({ service, payment, defaultWhatsapp, onClose, onDone }) {
	const [whatsapp, setWhatsapp] = (0, import_react.useState)(defaultWhatsapp);
	const [note, setNote] = (0, import_react.useState)("");
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const unpublished = payment.accountNumber === "0123456789" || !payment.accountNumber;
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "Escape") onClose();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	async function onSubmit(event) {
		event.preventDefault();
		if (!receipt) {
			setError("Upload a photo of your payment receipt");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			await requestService({ data: {
				serviceId: service.id,
				whatsapp,
				receipt,
				note
			} });
			await onDone();
		} catch (err) {
			setError(messageOf(err));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/40 sm:items-center sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-lg bg-sheet p-5 shadow-lg sm:rounded-lg",
			role: "dialog",
			"aria-labelledby": "request-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-ink/50",
							children: service.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "request-title",
							className: "mt-1 font-display text-3xl",
							children: service.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl tabular-nums text-gold",
							children: naira(service.priceNaira)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Close"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-md border border-ink/10 bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-ink/50",
							children: "Pay into"
						}),
						unpublished ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: "The office has not published a real account yet. You can browse services, but payment is paused until they update the bank details."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-2 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-ink/60",
										children: "Bank"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-medium",
										children: payment.bankName
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-ink/60",
										children: "Account name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-right font-medium",
										children: payment.accountName
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-ink/60",
										children: "Account number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-display text-xl tabular-nums",
										children: payment.accountNumber
									})]
								})
							]
						}),
						payment.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-ink/70",
							children: payment.note
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Your WhatsApp number",
							hint: "This is where the service will be delivered.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								required: true,
								inputMode: "tel",
								placeholder: "0803 000 0000",
								value: whatsapp,
								onChange: (e) => setWhatsapp(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Payment receipt",
							hint: "A photo of the transfer alert or teller.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/jpeg,image/png,image/webp",
								className: "block w-full text-sm file:mr-3 file:min-h-11 file:rounded-md file:border-0 file:bg-forest file:px-3 file:text-sm file:text-paper",
								onChange: (e) => {
									const file = e.target.files?.[0];
									if (!file) return;
									compressImage(file, 1280).then(setReceipt).catch((err) => setError(messageOf(err)));
								}
							})
						}),
						receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: receipt,
							alt: "Receipt preview",
							className: "max-h-48 w-full rounded-md object-contain bg-paper"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Note for the office",
							hint: "Optional. Subjects, exam year, or registration details.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
								value: note,
								onChange: (e) => setNote(e.target.value),
								maxLength: 500
							})
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full",
							disabled: busy || unpublished,
							children: busy ? "Sending…" : "Send receipt"
						})
					]
				})
			]
		})
	});
}
function ReceiptButton({ id }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "Your payment receipt",
		className: "mt-3 max-h-64 w-full rounded-md object-contain bg-paper"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		className: "mt-2 px-0",
		disabled: busy,
		onClick: () => {
			setBusy(true);
			fetchReceipt({ data: id }).then((row) => setSrc(row.receipt)).catch((err) => toast.error(messageOf(err))).finally(() => setBusy(false));
		},
		children: busy ? "Loading receipt…" : "View receipt"
	});
}
//#endregion
export { PortalPage as component };
