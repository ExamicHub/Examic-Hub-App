import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal-shared-BG4-ZQHK.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-BhcLuWvF.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-EwJwFJM0.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
/** Shared portal rules. No server imports — safe on the client. */
var PLACEHOLDER_ACCOUNT = "0123456789";
var ORDER_STATUSES = [
	"pending",
	"confirmed",
	"completed",
	"rejected"
];
var MALPRACTICE = /\b(runz|expos?|leaked questions|exam leak|malpractice|question dump|live questions)\b|\b(sell|buy|purchase)\b.{0,48}\b(answers?|questions?)\b|\b(answers?|questions?)\b.{0,48}\b(before the exam|during the exam)\b/i;
function isMalpracticeCopy(text) {
	return MALPRACTICE.test(text);
}
function naira(amount) {
	return new Intl.NumberFormat("en-NG", {
		style: "currency",
		currency: "NGN",
		maximumFractionDigits: 0
	}).format(amount);
}
function whatsappHref(raw) {
	let digits = raw.replace(/\D/g, "");
	if (digits.startsWith("0")) digits = `234${digits.slice(1)}`;
	else if (digits.length === 10) digits = `234${digits}`;
	return `https://wa.me/${digits}`;
}
function assertImageData(value, label) {
	if (typeof value !== "string" || !value.startsWith("data:image/")) throw new Error(`${label} must be a photo`);
	const comma = value.indexOf(",");
	const meta = comma === -1 ? "" : value.slice(0, comma);
	if (!/^data:image\/(jpeg|png|webp);base64$/i.test(meta)) throw new Error(`${label} must be a JPG, PNG, or WebP`);
	if (value.length > 5e5) throw new Error(`${label} is too large. Try a smaller photo.`);
	return value;
}
function assertWhatsapp(value) {
	if (typeof value !== "string") throw new Error("Enter a WhatsApp number");
	const trimmed = value.trim();
	const digits = trimmed.replace(/\D/g, "");
	if (digits.length < 10 || digits.length > 15) throw new Error("Enter a valid WhatsApp number");
	return trimmed;
}
//#endregion
export { authMiddleware as a, whatsappHref as c, assertWhatsapp as i, PLACEHOLDER_ACCOUNT as n, isMalpracticeCopy as o, assertImageData as r, naira as s, ORDER_STATUSES as t };
