import { i as hashPassword$1, r as getSql } from "./db-Cy8KniRL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/seed.server-B2VMP_8w.js
/** Office account. Server-only — never imported from a client component. */
var ADMIN_EMAIL = "examichubeduconsult@gmail.com";
var ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "";
var ADMIN_NAME = "Examic Hub Admin";
var STARTER_SERVICES = [
	{
		title: "Printing of JAMB result",
		description: "We print your JAMB result slip and send a clear copy on WhatsApp.",
		price: 1500,
		category: "Documents"
	},
	{
		title: "Printing of JAMB admission letter",
		description: "A printed JAMB admission letter for your school file, plus a scan.",
		price: 2e3,
		category: "Documents"
	},
	{
		title: "Tutorial class",
		description: "Monthly lesson support. Add your subjects in the note when you pay.",
		price: 15e3,
		category: "Classes"
	},
	{
		title: "JAMB registration support",
		description: "Help completing your UTME registration and profile correctly.",
		price: 5e3,
		category: "Registration"
	},
	{
		title: "WAEC result reprint",
		description: "We help you check and reprint your WAEC result.",
		price: 3e3,
		category: "Documents"
	},
	{
		title: "NECO result reprint",
		description: "We help you check and reprint your NECO result.",
		price: 3e3,
		category: "Documents"
	},
	{
		title: "O'Level upload to JAMB",
		description: "Upload of your O'Level result onto your JAMB profile.",
		price: 2500,
		category: "Registration"
	},
	{
		title: "Change of institution or course",
		description: "Support to process a change of institution or course on JAMB.",
		price: 4e3,
		category: "Registration"
	}
];
var pending = null;
function ensureSeed() {
	if (!pending) pending = runSeed().catch((err) => {
		pending = null;
		throw err;
	});
	return pending;
}
async function runSeed() {
	const sql = await getSql();
	let adminId = (await sql`
    select id from "user" where lower(email) = ${ADMIN_EMAIL} limit 1
  `)[0]?.id;
	if (!adminId && ADMIN_PASSWORD) {
		adminId = crypto.randomUUID();
		const passwordHash = await hashPassword$1(ADMIN_PASSWORD);
		await sql`
      insert into "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt")
      values (${adminId}, ${ADMIN_NAME}, ${ADMIN_EMAIL}, true, now(), now())
    `;
		await sql`
      insert into "account" (
        "id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt"
      )
      values (
        ${crypto.randomUUID()}, ${adminId}, 'credential', ${adminId}, ${passwordHash}, now(), now()
      )
    `;
	} else if (!adminId) console.warn("[seed] ADMIN_PASSWORD is not set; office account not created.");
	else if (ADMIN_PASSWORD) {
		if ((await sql`
      select id from "account"
      where "userId" = ${adminId} and "providerId" = 'credential'
      limit 1
    `).length === 0) {
			const passwordHash = await hashPassword$1(ADMIN_PASSWORD);
			await sql`
        insert into "account" (
          "id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt"
        )
        values (
          ${crypto.randomUUID()}, ${adminId}, 'credential', ${adminId}, ${passwordHash}, now(), now()
        )
      `;
		}
	}
	if (adminId) await sql`
      insert into profiles (user_id, email, full_name, role)
      values (${adminId}, ${ADMIN_EMAIL}, ${ADMIN_NAME}, 'admin')
      on conflict (user_id) do update
        set role = 'admin', email = ${ADMIN_EMAIL}
    `;
	if ((await sql`
    select key from portal_flags where key = 'seeded' limit 1
  `).length > 0) return;
	if (((await sql`select count(*)::int as n from services`)[0]?.n ?? 0) === 0) {
		let order = 1;
		for (const service of STARTER_SERVICES) {
			await sql`
        insert into services (title, description, price_naira, category, sort_order)
        values (
          ${service.title},
          ${service.description},
          ${service.price},
          ${service.category},
          ${order}
        )
      `;
			order += 1;
		}
	}
	await sql`
    insert into payment_settings (id, bank_name, account_name, account_number, note)
    values (
      1,
      'Access Bank',
      'Examic Hub Edu Consult',
      '0123456789',
      'Transfer the exact amount and use your full name as the narration.'
    )
    on conflict (id) do nothing
  `;
	await sql`
    insert into portal_flags (key, value) values ('seeded', '1')
    on conflict (key) do nothing
  `;
}
//#endregion
export { ensureSeed };
