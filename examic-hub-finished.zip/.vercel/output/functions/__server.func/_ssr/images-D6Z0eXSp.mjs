//#region node_modules/.nitro/vite/services/ssr/assets/images-D6Z0eXSp.js
/** Shrink a photo in the browser before it is stored. */
function compressImage(file, maxEdge) {
	if (!file.type.startsWith("image/")) return Promise.reject(/* @__PURE__ */ new Error("Please choose a JPG or PNG photo"));
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			URL.revokeObjectURL(url);
			const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				reject(/* @__PURE__ */ new Error("Could not read that photo"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			let quality = .72;
			let data = canvas.toDataURL("image/jpeg", quality);
			while (data.length > 48e4 && quality > .42) {
				quality -= .1;
				data = canvas.toDataURL("image/jpeg", quality);
			}
			if (data.length > 5e5) {
				reject(/* @__PURE__ */ new Error("That photo is still too large. Try another one."));
				return;
			}
			resolve(data);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Could not read that photo. Use a JPG or PNG."));
		};
		img.src = url;
	});
}
//#endregion
export { compressImage as t };
