import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, m as useRouterState, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as hasGateSessionMarker } from "./server-BO0QHZyP.mjs";
import { d as whoAmI } from "./router-BUF_86uw.mjs";
import { r as signOut, t as authClient } from "./client-BhcLuWvF.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BebHXyQF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-11 w-11 place-items-center rounded-md bg-forest font-display text-lg text-paper",
			children: "Eh"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-display text-lg leading-none",
				children: "Examic Hub"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 block h-0.5 w-8 bg-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs uppercase tracking-widest text-ink/55",
				children: "Edu Consult"
			})
		] })]
	});
}
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { user, isPending } = useCurrentUserState();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [role, setRole] = (0, import_react.useState)(null);
	const [avatar, setAvatar] = (0, import_react.useState)(null);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	(0, import_react.useEffect)(() => {
		if (!mounted || !user) {
			setRole(null);
			setAvatar(null);
			return;
		}
		let cancelled = false;
		whoAmI().then((me) => {
			if (cancelled) return;
			setRole(me.role);
			setAvatar(me.avatar);
		}).catch(() => {
			if (!cancelled) setRole(null);
		});
		return () => {
			cancelled = true;
		};
	}, [mounted, user?.id]);
	const showSession = mounted && !isPending;
	const gateLocked = showSession && hasGateSessionMarker() && !window.sessionStorage.getItem("grok-auth.bearer-token");
	const linkClass = (path) => cn("inline-flex min-h-11 items-center rounded-md px-3 text-sm font-medium", pathname === path ? "bg-forest text-paper" : "text-ink hover:bg-ink/5");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-ink/10 bg-sheet",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ml-auto flex flex-wrap items-center gap-1",
					children: showSession && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/portal",
							className: linkClass("/portal"),
							children: "Portal"
						}),
						role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin",
							className: linkClass("/admin"),
							children: "Office"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: linkClass("/login"),
							children: "Staff"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 hidden h-6 w-px bg-ink/10 sm:block" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex min-h-11 items-center gap-2 px-1 text-sm",
							children: [avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: avatar,
								alt: "",
								className: "h-8 w-8 rounded-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-full bg-forest/10 text-xs font-medium text-forest",
								children: (user.displayName ?? user.primaryEmail ?? "S").charAt(0).toUpperCase()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-32 truncate",
								children: user.displayName ?? "Student"
							})]
						}),
						!gateLocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: signingOut,
							onClick: () => {
								setSigningOut(true);
								signOut("/").catch(() => setSigningOut(false));
							},
							className: "inline-flex min-h-11 items-center px-2 text-sm text-ink/70 underline-offset-4 hover:underline disabled:opacity-60",
							children: signingOut ? "Signing out…" : "Sign out"
						}) : null
					] }) : showSession ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: linkClass("/login"),
						children: "Sign in"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/signup",
						className: "inline-flex min-h-11 items-center rounded-md bg-forest px-3 text-sm font-medium text-paper",
						children: "Create account"
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-11 w-28 animate-pulse rounded-md bg-ink/10" })
				})]
			})
		}), children]
	});
}
//#endregion
export { cn as n, useCurrentUserState as r, Shell as t };
