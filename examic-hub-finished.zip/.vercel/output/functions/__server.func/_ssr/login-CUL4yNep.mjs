import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as whoAmI } from "./router-BUF_86uw.mjs";
import { r as useCurrentUserState, t as Shell } from "./shell-BebHXyQF.mjs";
import { n as Field, o as TextInput, s as messageOf, t as Button } from "./ui-B1_fz_-z.mjs";
import { t as emailAuth } from "./email-auth-Be3BaIBm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CUL4yNep.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [role, setRole] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => setMounted(true), []);
	(0, import_react.useEffect)(() => {
		if (!mounted || !user) {
			setRole(null);
			return;
		}
		let cancelled = false;
		whoAmI().then((me) => {
			if (!cancelled) setRole(me.role);
		}).catch(() => {
			if (!cancelled) setRole(null);
		});
		return () => {
			cancelled = true;
		};
	}, [mounted, user?.id]);
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		setBusy(true);
		try {
			await emailAuth("sign-in", {
				email: email.trim(),
				password
			});
			const me = await whoAmI();
			window.location.assign(me.role === "admin" ? "/admin" : "/portal");
		} catch (err) {
			setError(messageOf(err));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-5xl gap-8 px-4 py-10 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-widest text-forest",
				children: "Sign in"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Welcome back."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-ink/70",
				children: "Students use the email they registered with. Office staff sign in with the consult email to manage services, bank details, and receipts."
			}),
			mounted && !isPending && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 rounded-md border border-ink/10 bg-sheet px-4 py-3 text-sm",
				children: [
					"You are signed in as ",
					user.primaryEmail ?? user.displayName,
					".",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: role === "admin" ? "/admin" : "/portal",
						className: "font-medium text-forest underline-offset-4 hover:underline",
						children: "Continue"
					})
				]
			}) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4 rounded-lg border border-ink/10 bg-sheet p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "email",
						autoComplete: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Password",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "password",
						autoComplete: "current-password",
						required: true,
						value: password,
						onChange: (e) => setPassword(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy,
					children: busy ? "Signing in…" : "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ink/70",
					children: [
						"New student?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							className: "font-medium text-forest underline-offset-4 hover:underline",
							children: "Create an account"
						})
					]
				})
			]
		})]
	}) });
}
//#endregion
export { LoginPage as component };
