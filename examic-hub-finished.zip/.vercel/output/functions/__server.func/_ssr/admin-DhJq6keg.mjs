import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as whatsappHref, n as PLACEHOLDER_ACCOUNT, s as naira, t as ORDER_STATUSES } from "./portal-shared-BG4-ZQHK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as updatePayment, i as getAdminHome, n as deleteService, r as fetchReceipt, s as updateOrder, u as upsertService } from "./router-BUF_86uw.mjs";
import { r as useCurrentUserState, t as Shell } from "./shell-BebHXyQF.mjs";
import { a as TextArea, i as StatusPill, n as Field, o as TextInput, r as PageSkeleton, s as messageOf, t as Button } from "./ui-B1_fz_-z.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DhJq6keg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_SERVICE = {
	id: null,
	title: "",
	description: "",
	priceNaira: "",
	category: "Documents",
	active: true
};
function AdminPage() {
	const { user, isPending } = useCurrentUserState();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [home, setHome] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("requests");
	const [filter, setFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => setMounted(true), []);
	async function reload() {
		setHome(await getAdminHome());
	}
	(0, import_react.useEffect)(() => {
		if (!mounted || !user) return;
		let cancelled = false;
		getAdminHome().then((next) => {
			if (!cancelled) setHome(next);
		}).catch((err) => {
			if (!cancelled) setError(messageOf(err));
		});
		return () => {
			cancelled = true;
		};
	}, [mounted, user?.id]);
	const visible = (0, import_react.useMemo)(() => {
		if (!home) return [];
		if (filter === "all") return home.orders;
		return home.orders.filter((order) => order.status === filter);
	}, [home, filter]);
	if (!mounted || isPending || user && !home && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSkeleton, {}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!home) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Office desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-ink/70",
				children: error === "Forbidden" ? "This desk is only for the office account. Sign in with the consult email." : error ?? "Could not open the office."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/login",
				className: "mt-6 inline-flex min-h-11 items-center rounded-md bg-forest px-4 text-sm font-medium text-paper",
				children: "Staff sign in"
			})
		]
	}) });
	const open = home.orders.filter((order) => order.status === "pending" || order.status === "confirmed").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-widest text-forest",
				children: "Office"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Examic Hub desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-6 grid grid-cols-3 gap-3",
				children: [
					["Open", open],
					["Services", home.services.filter((service) => service.active).length],
					["Done", home.orders.filter((order) => order.status === "completed").length]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-ink/10 bg-sheet px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs uppercase tracking-widest text-ink/50",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: value
					})]
				}, String(label)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [
					["requests", "Requests"],
					["services", "Services"],
					["account", "Bank account"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: tab === id ? "primary" : "line",
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			tab === "requests" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						current: filter,
						value: "all",
						onPick: setFilter,
						label: "All"
					}), ORDER_STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						current: filter,
						value: status,
						onPick: setFilter,
						label: status
					}, status))]
				}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg border border-dashed border-ink/20 p-6 text-sm text-ink/70",
					children: "No requests in this list."
				}) : visible.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order,
					onChanged: async () => {
						await reload();
					}
				}, order.id))]
			}) : null,
			tab === "services" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicesPanel, {
				services: home.services,
				onChanged: async () => {
					toast.success("Services updated");
					await reload();
				}
			}) : null,
			tab === "account" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountPanel, {
				payment: home.payment,
				onChanged: async () => {
					toast.success("Bank details saved");
					await reload();
				}
			}) : null
		]
	}) });
}
function FilterChip({ current, value, label, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => onPick(value),
		className: current === value ? "min-h-11 rounded-full bg-ink px-3 text-sm text-paper" : "min-h-11 rounded-full border border-ink/15 bg-sheet px-3 text-sm capitalize",
		children: label
	});
}
function OrderCard({ order, onChanged }) {
	const [status, setStatus] = (0, import_react.useState)(order.status);
	const [adminNote, setAdminNote] = (0, import_react.useState)(order.adminNote);
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		try {
			await updateOrder({ data: {
				id: order.id,
				status,
				adminNote
			} });
			toast.success("Request updated");
			await onChanged();
		} catch (err) {
			toast.error(messageOf(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-ink/10 bg-sheet p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: order.serviceTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: [
							order.studentName,
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "break-all",
								children: order.studentEmail
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm tabular-nums text-ink/70",
						children: [
							naira(order.priceNaira),
							" · ",
							formatWhen(order.createdAt)
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: order.status })]
			}),
			order.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-ink/75",
				children: ["Student note: ", order.note]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "inline-flex min-h-11 items-center rounded-md bg-forest px-3 text-sm font-medium text-paper",
					href: whatsappHref(order.whatsapp),
					target: "_blank",
					rel: "noreferrer",
					children: ["WhatsApp ", order.whatsapp]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "line",
					disabled: busy,
					onClick: () => {
						if (receipt) {
							setReceipt(null);
							return;
						}
						setBusy(true);
						fetchReceipt({ data: order.id }).then((row) => setReceipt(row.receipt)).catch((err) => toast.error(messageOf(err))).finally(() => setBusy(false));
					},
					children: receipt ? "Hide receipt" : "View receipt"
				})]
			}),
			receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: receipt,
				alt: "Payment receipt",
				className: "mt-3 max-h-80 w-full rounded-md object-contain bg-paper"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-[12rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "min-h-11 w-full rounded-md border border-ink/15 bg-sheet px-3 text-base",
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: ORDER_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: item
						}, item))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note to the student",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: adminNote,
						onChange: (e) => setAdminNote(e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3",
				disabled: busy,
				onClick: () => void save(),
				children: busy ? "Saving…" : "Save request"
			})
		]
	});
}
function ServicesPanel({ services, onChanged }) {
	const [draft, setDraft] = (0, import_react.useState)(EMPTY_SERVICE);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await upsertService({ data: {
				id: draft.id,
				title: draft.title,
				description: draft.description,
				priceNaira: Number(draft.priceNaira),
				category: draft.category,
				active: draft.active
			} });
			setDraft(EMPTY_SERVICE);
			await onChanged();
		} catch (err) {
			setError(messageOf(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 grid gap-4 lg:grid-cols-[1fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-3 rounded-lg border border-ink/10 bg-sheet p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: draft.id ? "Edit service" : "Add a service"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.title,
						onChange: (e) => setDraft({
							...draft,
							title: e.target.value
						}),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Description",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: draft.description,
						onChange: (e) => setDraft({
							...draft,
							description: e.target.value
						}),
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price (₦)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							value: draft.priceNaira,
							onChange: (e) => setDraft({
								...draft,
								priceNaira: e.target.value.replace(/[^\d]/g, "")
							}),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.category,
							onChange: (e) => setDraft({
								...draft,
								category: e.target.value
							}),
							required: true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: draft.active,
						onChange: (e) => setDraft({
							...draft,
							active: e.target.checked
						})
					}), "Visible to students"]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Saving…" : draft.id ? "Update service" : "Add service"
					}), draft.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => setDraft(EMPTY_SERVICE),
						children: "Cancel"
					}) : null]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-lg border border-ink/10 bg-sheet p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-start justify-between gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-ink/50",
							children: service.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl",
							children: service.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-ink/70",
							children: service.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-2xl tabular-nums text-gold",
							children: naira(service.priceNaira)
						}),
						!service.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs uppercase tracking-widest text-ink/50",
							children: "Hidden"
						}) : null
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						onClick: () => setDraft({
							id: service.id,
							title: service.title,
							description: service.description,
							priceNaira: String(service.priceNaira),
							category: service.category,
							active: service.active
						}),
						children: "Edit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							if (!window.confirm(`Remove “${service.title}”? Requests already made will keep their copy.`)) return;
							deleteService({ data: service.id }).then(() => onChanged()).catch((err) => toast.error(messageOf(err)));
						},
						children: "Remove"
					})]
				})]
			}, service.id))
		})]
	});
}
function AccountPanel({ payment, onChanged }) {
	const [bankName, setBankName] = (0, import_react.useState)(payment.bankName);
	const [accountName, setAccountName] = (0, import_react.useState)(payment.accountName);
	const [accountNumber, setAccountNumber] = (0, import_react.useState)(payment.accountNumber);
	const [note, setNote] = (0, import_react.useState)(payment.note);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const placeholder = payment.accountNumber === PLACEHOLDER_ACCOUNT;
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await updatePayment({ data: {
				bankName,
				accountName,
				accountNumber,
				note
			} });
			await onChanged();
		} catch (err) {
			setError(messageOf(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mt-6 max-w-xl space-y-3 rounded-lg border border-ink/10 bg-sheet p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Account students pay into"
			}),
			placeholder ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-gold/20 px-3 py-2 text-sm",
				children: "This is a placeholder account. Replace it with the real office account before anyone pays."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink/70",
				children: "Students see these details when they request a service."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Bank",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: bankName,
					onChange: (e) => setBankName(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Account name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: accountName,
					onChange: (e) => setAccountName(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Account number",
				hint: "10 digits.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: accountNumber,
					onChange: (e) => setAccountNumber(e.target.value.replace(/[^\d]/g, "").slice(0, 10)),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note shown with the account",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
					value: note,
					onChange: (e) => setNote(e.target.value)
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				children: busy ? "Saving…" : "Save account"
			})
		]
	});
}
function formatWhen(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	return new Intl.DateTimeFormat("en-NG", {
		day: "numeric",
		month: "short",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
//#endregion
export { AdminPage as component };
