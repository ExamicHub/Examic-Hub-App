//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cb4oAuHk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/tmp/gw/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/login",
			"/portal",
			"/signup",
			"/api/auth/$"
		],
		preloads: ["/assets/index-Bj4s7Z92.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bj4s7Z92.js"
		} }]
	},
	"/": {
		filePath: "/tmp/gw/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CR0zkxN2.js", "/assets/shell-DtZJU-ag.js"]
	},
	"/admin": {
		filePath: "/tmp/gw/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-D2wrPmEy.js",
			"/assets/shell-DtZJU-ag.js",
			"/assets/ui-BBMyt1C1.js",
			"/assets/portal-shared-DDULLqL1.js"
		]
	},
	"/login": {
		filePath: "/tmp/gw/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DcBH7Pv9.js",
			"/assets/shell-DtZJU-ag.js",
			"/assets/ui-BBMyt1C1.js",
			"/assets/email-auth-CVHUwFvK.js"
		]
	},
	"/portal": {
		filePath: "/tmp/gw/src/routes/portal.tsx",
		children: void 0,
		preloads: [
			"/assets/portal-CM2Q8gzh.js",
			"/assets/shell-DtZJU-ag.js",
			"/assets/ui-BBMyt1C1.js",
			"/assets/portal-shared-DDULLqL1.js",
			"/assets/images-DYl_G1oU.js"
		]
	},
	"/signup": {
		filePath: "/tmp/gw/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-_y30tra1.js",
			"/assets/shell-DtZJU-ag.js",
			"/assets/ui-BBMyt1C1.js",
			"/assets/email-auth-CVHUwFvK.js",
			"/assets/images-DYl_G1oU.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
